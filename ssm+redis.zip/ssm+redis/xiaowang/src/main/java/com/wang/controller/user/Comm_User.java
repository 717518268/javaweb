package com.wang.controller.user;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.ibatis.annotations.Param;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.Commodity_table;
import com.wang.service.Commodity_tableService;
@SuppressWarnings("all")
@Controller
public class Comm_User {
	@Autowired
	private RedisTemplate redisTemplate;
	@Autowired
	private Commodity_tableService commodity_tableService;
	private Logger log=Logger.getLogger(this.getClass());
	@RequestMapping("/countComm")
	@ResponseBody
	public Object getCount(){
		int index=commodity_tableService.CountAllComment_Service();
		return index;
	}
	
	 
	@RequestMapping("/Comm_USer_All")
	@ResponseBody
	public List<Commodity_table>getAll(){
	 
		List<Commodity_table>list=(List<Commodity_table>) redisTemplate.opsForValue().get("Comm_List");
		if(list==null){
			list=commodity_tableService.selectListComm_table_Service();
			redisTemplate.opsForValue().set("Comm_List", list, 5, TimeUnit.HOURS);
		}
		
		return list;
	}
	
	 
	@RequestMapping("/DeleteComm_USER_One")
	@ResponseBody
	public Object deleteComm(@Param("id")Integer id){
		int index=commodity_tableService.deleteByPrimaryKeyID_Service(id);
		/*File deleteFile = new File(path,fileName);
        if (deleteFile.exists()){
            deleteFile.delete();
        }*/
		redisTemplate.delete("Comm_List");
		return index;
	}
	
	
}
