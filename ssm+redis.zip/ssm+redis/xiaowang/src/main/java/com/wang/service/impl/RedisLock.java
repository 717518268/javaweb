package com.wang.service.impl;

public class RedisLock {

}
