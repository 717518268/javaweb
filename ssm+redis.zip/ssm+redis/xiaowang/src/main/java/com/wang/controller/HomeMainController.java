package com.wang.controller;

import java.util.ArrayList;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.Param;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.Address_table;
import com.wang.pojo.Cart_table;
import com.wang.pojo.Commodity_table;
import com.wang.pojo.Down_Table;
import com.wang.pojo.Main_table;
import com.wang.pojo.Order_table;
import com.wang.pojo.Register_table;
import com.wang.service.Address_tableService;
import com.wang.service.Commodity_tableService;
import com.wang.service.Main_tableService;
import com.wang.service.Order_tableService;
import com.wang.service.util.OrderNumber;
import com.wang.service.util.RedisTempt_The_Key;
@SuppressWarnings("all")
@Controller
public class HomeMainController {
	//跳转的View
	private  static final String VIEW="homemain";
	/**
	 * 依赖注入主页数据
	 */
	@Autowired
	private Main_tableService main_tableService;
	 
	@Autowired
	private RedisTemplate  redisTemplate;
	 
	protected volatile ReentrantLock lock=new ReentrantLock();
	
 
	
	/**
	 * 请求路径
	 * @return
	 * 
	 */ 
	 
	@RequestMapping("/homemain")
	public String homemainView(Model model){
		List<Main_table>listmain_table=(List<Main_table>) redisTemplate.opsForValue().get("gethomemain");
		if(listmain_table==null){
			listmain_table=main_tableService.selectByMain_tableService();
			redisTemplate.opsForValue().set("gethomemain", listmain_table);
		}
		/*List<Main_table> listmain_table=main_tableService.selectByMain_tableService();*/
		model.addAttribute("main_table", listmain_table);
		
		return VIEW;
	}
	 
	
}
