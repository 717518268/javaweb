package com.wang.controller;

import java.awt.Color;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class code {
	
	@RequestMapping("/day")
	public String co(){
		return "day";
	}
	//验证码
	@RequestMapping("/getCode")
	public void getcode(HttpServletRequest request,HttpServletResponse response) throws Exception{
		request.setCharacterEncoding("utf-8");
		
		Map<String, Object> codeMap =getcode();

	        
	        HttpSession session = request.getSession();
	        session.setAttribute("code", codeMap.get("code").toString());

	       
	        response.setHeader("Pragma", "no-cache");
	        response.setHeader("Cache-Control", "no-cache");
	        response.setDateHeader("Expires", -1);

	        response.setContentType("image/jpeg");

	        // 锟斤拷图锟斤拷锟斤拷锟斤拷锟絊ervlet锟斤拷锟斤拷锟斤拷小锟�
	        ServletOutputStream sos;
	        try {
	            sos = response.getOutputStream();
	            ImageIO.write((RenderedImage) codeMap.get("codePic"), "jpeg", sos);
	            sos.close();
	        } catch (IOException e) {
	            
	            e.printStackTrace();
	        }
	}
	
	 private static int width = 90;//code the img the width
	  private static int height = 30;// code img the height
	  private static int codeCount = 4;// code content is 4
	  private  static int xx=15;
	  private static int fontHeight = 18;
	  int codeY = 16;
	  private static char[] codeSequence = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
	             'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

	public Map<String, Object>  getcode(){
		   BufferedImage buffImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
	       
	         Graphics gd = buffImg.getGraphics();
	        
	         Random random = new Random();
	       
	        gd.setColor(Color.WHITE);
	         gd.fillRect(0, 0, width, height);
	 
        // 锟
	        Font font = new Font("Fixedsys", Font.BOLD, fontHeight);
	         // 锟斤拷锟斤拷锟斤拷锟藉。
        gd.setFont(font);
	 
	         // 锟斤拷锟竭匡拷
	         gd.setColor(Color.BLACK);
	         gd.drawRect(0, 0, width - 1, height - 1);
	 
	         // 锟斤拷锟斤拷锟斤拷锟�40锟斤拷锟斤拷锟斤拷锟竭ｏ拷使图锟斤拷锟叫碉拷锟斤拷证锟诫不锟阶憋拷锟斤拷锟斤拷锟斤拷锟斤拷探锟解到锟斤拷
	         gd.setColor(Color.BLACK);
	         for (int i = 0; i < 30; i++) {
	        	 int x = random.nextInt(width);
	             int y = random.nextInt(height);
	             int xl = random.nextInt(12);
	             int yl = random.nextInt(12);
	             gd.drawLine(x, y, x + xl, y + yl);
	        }
	
	        // randomCode锟斤拷锟节憋拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟街わ拷耄拷员锟斤拷没锟斤拷锟铰硷拷锟斤拷锟斤拷锟斤拷证锟斤拷
	         StringBuffer randomCode = new StringBuffer();
	         int red = 0, green = 0, blue = 0;
	 
	         // 锟斤拷锟斤拷锟斤拷锟絚odeCount锟斤拷锟街碉拷锟斤拷证锟诫。
	         for (int i = 0; i < codeCount; i++) {
            // 锟矫碉拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟街わ拷锟斤拷锟斤拷帧锟�
	            String code = String.valueOf(codeSequence[random.nextInt(36)]);
	            // 
	            red = random.nextInt(255);
	             green = random.nextInt(255);
	             blue = random.nextInt(255);
	 
	             // 锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟缴拷锟斤拷锟街わ拷锟斤拷锟狡碉拷图锟斤拷锟叫★拷
	            gd.setColor(new Color(red, green, blue));
	             gd.drawString(code, (i + 1) * xx, codeY);
	 
	             // 锟斤拷锟斤拷锟斤拷锟斤拷锟侥革拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷一锟斤拷
            randomCode.append(code);
	         }
	         Map<String,Object> map  =new HashMap<String,Object>();
	         //锟斤拷锟斤拷锟街わ拷锟�
	         map.put("code", randomCode);
	         //放进map里
        map.put("codePic", buffImg);
	     return map;
		
	}
	
	@RequestMapping("/validcode")
	public  void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//创建一张图片
		//单位:像素
		BufferedImage image = new BufferedImage(200, 100, BufferedImage.TYPE_INT_RGB);
		
		//透明的玻璃
		//向画板上画内容之前必须先设置画笔.
		Graphics2D gra = image.createGraphics();
		
		gra.setColor(Color.WHITE);
		//从哪个坐标开始填充, 后两个参数,矩形区域
		gra.fillRect(0, 0, 200, 100);
		
		List<Integer> randList = new ArrayList<Integer>();
		Random random =new Random();
		for (int i = 0 ;i<4;i++) {
			randList.add(random.nextInt(10));
		}
		//设置字体
		gra.setFont(new Font("宋体",Font.ITALIC|Font.BOLD,40));
		Color[] colors = new Color[]{Color.RED,Color.YELLOW,Color.BLUE,Color.GREEN,Color.PINK,Color.GRAY};
		for (int i = 0; i < randList.size(); i++) {
			gra.setColor(colors[random.nextInt(colors.length)]);
			gra.drawString(randList.get(i)+"", i*40, 70+(random.nextInt(21)-10));
		}
		
		for (int i = 0; i < 2; i++) {
			gra.setColor(colors[random.nextInt(colors.length)]);
			//画横线
			gra.drawLine(0, random.nextInt(101), 200, random.nextInt(101));
		}
		
		ServletOutputStream outputStream = resp.getOutputStream();
		//工具类
		ImageIO.write(image, "jpg", outputStream);
		
		//把验证码放入到session中
		HttpSession session = req.getSession();
		session.setAttribute("codeInt", ""+randList.get(0)+randList.get(1)+randList.get(2)+randList.get(3));
	}
}
