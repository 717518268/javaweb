package com.wang.controller.user;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.ibatis.annotations.Param;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.Address_table;
import com.wang.service.Address_tableService;
@SuppressWarnings("all")
@Controller
public class Address_USer {
	@Autowired
	private RedisTemplate redisTemplate;
	@Autowired
	private Address_tableService address_tableService;
	private Logger log=Logger.getLogger(Address_USer.class);
	@RequestMapping("/getAddreCount")
	@ResponseBody
	public Object getCount(){
		
		int count=address_tableService.CountComment();
		return count;
	}
	
	
	/**
	 * 查询所有的地址信息
	 * @return
	 */
	 
	@RequestMapping("/GetAddressAllList")
	@ResponseBody
	public List<Address_table>getAddreass(){
		
		List<Address_table>list=(List<Address_table>) redisTemplate.opsForValue().get("GetAddress");
		if(list==null){
			 list=address_tableService.selectByAddress_table_ALL_Service();
			 redisTemplate.opsForValue().set("GetAddress", list, 1, TimeUnit.HOURS);
		}

		return list;
	}
	
	 /**
	  * 删除一个地址
	  * 用户管理中心
	  * @param address_id
	  * @return
	  */
	@RequestMapping("/deleteAdd_oneTable")
	@ResponseBody
	public Object deleetAddress(@Param("address_id")Integer address_id){
		int indexdele=address_tableService.deleteByPrimaryKey_Service(address_id);
		redisTemplate.delete("GetAddress");
		return indexdele;
	}
	
	
	
	
	
}
