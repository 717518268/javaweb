package com.wang.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.Register_table;
import com.wang.service.util.RedisTempt_The_Key;

@Controller
public class GetToken {
	
	@RequestMapping("/gettoken/UsernameValue")
	@ResponseBody
	public Object gettokeng(HttpSession session){
		Register_table register_table=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		System.out.println("取用户对象");
		if(register_table==null){
			return "NoNull";
		}
		
		
		return register_table;
	}
	
}
