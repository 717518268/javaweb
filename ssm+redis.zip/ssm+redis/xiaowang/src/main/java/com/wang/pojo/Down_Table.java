package com.wang.pojo;

import java.io.Serializable;

public class Down_Table implements Serializable{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1451466600765978119L;

		private Integer did;

	    private String title;

	    private Integer count;

	    private Double price;

	    private String image1;

	    private String details;
	    private Integer time;
		public Integer getDid() {
			return did;
		}
		public void setDid(Integer did) {
			this.did = did;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public Integer getCount() {
			return count;
		}
		public void setCount(Integer count) {
			this.count = count;
		}
		public Double getPrice() {
			return price;
		}
		public void setPrice(Double price) {
			this.price = price;
		}
		public String getImage1() {
			return image1;
		}
		public void setImage1(String image1) {
			this.image1 = image1;
		}
		public String getDetails() {
			return details;
		}
		public void setDetails(String details) {
			this.details = details;
		}
		public Integer getTime() {
			return time;
		}
		public void setTime(Integer time) {
			this.time = time;
		}
		public static long getSerialversionuid() {
			return serialVersionUID;
		}
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((count == null) ? 0 : count.hashCode());
			result = prime * result + ((details == null) ? 0 : details.hashCode());
			result = prime * result + ((did == null) ? 0 : did.hashCode());
			result = prime * result + ((image1 == null) ? 0 : image1.hashCode());
			result = prime * result + ((price == null) ? 0 : price.hashCode());
			result = prime * result + ((time == null) ? 0 : time.hashCode());
			result = prime * result + ((title == null) ? 0 : title.hashCode());
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Down_Table other = (Down_Table) obj;
			if (count == null) {
				if (other.count != null)
					return false;
			} else if (!count.equals(other.count))
				return false;
			if (details == null) {
				if (other.details != null)
					return false;
			} else if (!details.equals(other.details))
				return false;
			if (did == null) {
				if (other.did != null)
					return false;
			} else if (!did.equals(other.did))
				return false;
			if (image1 == null) {
				if (other.image1 != null)
					return false;
			} else if (!image1.equals(other.image1))
				return false;
			if (price == null) {
				if (other.price != null)
					return false;
			} else if (!price.equals(other.price))
				return false;
			if (time == null) {
				if (other.time != null)
					return false;
			} else if (!time.equals(other.time))
				return false;
			if (title == null) {
				if (other.title != null)
					return false;
			} else if (!title.equals(other.title))
				return false;
			return true;
		}
		@Override
		public String toString() {
			return "Down_Table [did=" + did + ", title=" + title + ", count=" + count + ", price=" + price + ", image1="
					+ image1 + ", details=" + details + ", time=" + time + "]";
		}
		public Down_Table(String title, Integer count, Double price, String image1, String details, Integer time) {
			super();
			this.title = title;
			this.count = count;
			this.price = price;
			this.image1 = image1;
			this.details = details;
			this.time = time;
		}
		public Down_Table() {
			super();
			// TODO Auto-generated constructor stub
		}
		 
	    
	    
}
