package com.wang.dao;

import java.util.List;

import com.wang.pojo.CallMeTable;

public interface CallMeTableDao {
	
	/**
	 * 用户联系或者反馈的数据
	 * 返回一个列表
	 * <select id="selectByCallMEAllList" resultType="com.wang.pojo.CallMeTable">
    select
   
    <include refid="Base_Column_List" />
    
    from callme
     
  </select>
  
	 * @return
	 */
	public List<CallMeTable>selectByCallMEAllList();
	
	
	/**
	 * 根据id查询一个用户反馈的信息
	 *  <!--  
  根据id返回
  -->
  <select id="selectByCallMETable" resultMap="BaseResultMap" parameterType="java.lang.Integer" >
    select 
    <include refid="Base_Column_List" />
    from callme
    where id = #{id,jdbcType=INTEGER}
  </select>
  
	 * @param id
	 * @return
	 */
	public CallMeTable selectByCallMETable(Integer  id);
	
	
	/**
	 *   insert into callme (username, title, 
      email, message,time)
    values (#{username,jdbcType=VARCHAR}, #{title,jdbcType=VARCHAR}, 
      #{email,jdbcType=VARCHAR}, #{message,jdbcType=LONGVARCHAR},#{time,jdbcType=VARCHAR})
	 * @param CallMeTable
	 * @return
	 */
	public Integer insertCallMETable(CallMeTable CallMeTable);
	/**
	 * 插入一条信息
	 * @param CallMeTable
	 * @return
	 */
	public Integer insertCallMETableSQL(CallMeTable CallMeTable);
	/**
	 * 查总数
	 * select count(*) from callme
	 * @return
	 */
	public Integer countByCallMETable();
	/**
	 * 根据id删除
	 *  delete from callme
    where id = #{id,jdbcType=INTEGER}
	 * @param id
	 * @return
	 */
	public Integer deleteByCallMETableId(Integer id);
	
	/**
	 * 批量删除
	 * <!-- 批量删除 -->
  <delete id="deleteByCallMETableIdIDS" parameterType="java.lang.String">
    delete from callme where id in
  <foreach item="id" collection="array" index="no" open="(" separator="," close=")">
  #{id}
  </foreach>
  </delete>
  
	 * @return
	 */
	public int deleteByCallMETableIdIDS(String[]id);
	
	/**
	 * update callme
    set username = #{username,jdbcType=VARCHAR},
      title = #{title,jdbcType=VARCHAR},
      email = #{email,jdbcType=VARCHAR},
      message = #{message,jdbcType=LONGVARCHAR},
       time = #{time,jdbcType=VARCHAR}
    where id = #{id,jdbcType=INTEGER}
	 * @param callMeTable
	 * @return
	 */
	public Integer updateCallMETable(CallMeTable callMeTable);
	
}
