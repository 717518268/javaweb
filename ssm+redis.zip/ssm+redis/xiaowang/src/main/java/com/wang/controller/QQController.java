package com.wang.controller;

 
//@Controller
public class QQController {
	

	
	
	
	
}
