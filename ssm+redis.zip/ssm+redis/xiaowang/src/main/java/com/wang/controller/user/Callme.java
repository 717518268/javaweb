package com.wang.controller.user;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.CallMeTable;
import com.wang.service.CallMeTableService;
/**
 * 获取反馈量的controller
 * @author Administrator
 *
 */
@Controller
public class Callme {
	@Autowired
	private CallMeTableService callMeTableService;
	@RequestMapping("/getcallmeCount")
	@ResponseBody
	public Object getclaameCount(){
		
		int count=callMeTableService.countByCallMETable();
		return count;
	}
	
	@RequestMapping("/getListCallmeTable")
	@ResponseBody
	public List<CallMeTable>getListCallmeTable(){
		List<CallMeTable>list=callMeTableService.selectByCallMEAllList();
		return list;
	}
	@RequestMapping("/deleteCallmeid")
	@ResponseBody
	public Object deleteCallid(@Param("id")Integer id){
		
		int index=callMeTableService.deleteByCallMETableId(id);
		return index;
	}
	
}
