package com.wang.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class UpdateSuccessME {
	 
	@RequestMapping("/updateSuccess")
	public String getUpdateME(){
		
		return "updateSuccess";
	}
	
	
	
}
