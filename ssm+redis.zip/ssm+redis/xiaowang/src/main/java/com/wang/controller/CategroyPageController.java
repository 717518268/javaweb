package com.wang.controller;

import java.io.UnsupportedEncodingException;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.Cart_table;
import com.wang.pojo.Commodity_table;
import com.wang.pojo.Register_table;
import com.wang.service.Cart_tableService;
import com.wang.service.Commodity_tableService;
import com.wang.service.util.RedisTempt_The_Key;

/**
 * 分类也
 * @author Administrator
 *
 */
@Controller
public class CategroyPageController {
	 
	@Autowired
	private Commodity_tableService commodity_tableService;
	@Autowired
	private Cart_tableService cart_tableService;
	/**
	 * 进入分类页
	 * @param pn
	 * @param request
	 * @param title
	 * @return
	 */
	@RequestMapping("/categoryPageView")
	public String categrtoyPAgeView(Model model,@Param("title")String title){
		//测试阶段写死后端
	//	List<Commodity_table>list= commodity_tableService.selectListComm_table_Service();
		List<Commodity_table>list= commodity_tableService.selectListComm_tableTitle_Service(title);
		
		
		model.addAttribute("pageinfo", list);
		
		return "categoryPageView";
	}
	
	 
	/***
	 * 考虑ajax两个情况使用
	 * @return
	 */
	@RequestMapping("/getAllComment/TableList")
	@ResponseBody
	public List<Commodity_table>getAllCommentTableList(){
		List<Commodity_table>list= commodity_tableService.selectListComm_table_Service();
		return list;
	}
	
	
	
	
	/**
	 * 获取ip
	 * @param request
	 * @return
	 */
	public static String getIpAddr(HttpServletRequest request) {  
	    String ip = request.getHeader("x-forwarded-for");  
	    if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
	        ip = request.getHeader("Proxy-Client-IP");  
	    }  
	    if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
	        ip = request.getHeader("WL-Proxy-Client-IP");  
	    } 
	    if(ip == null || ip.length() == 0 || "X-Real-IP".equalsIgnoreCase(ip)) {  
	        ip = request.getHeader("X-Real-IP");  
	    }  
	    if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
	        ip = request.getRemoteAddr();  
	    }  
	    return ip;  
	}

	
	/**
	 * 添加到购物车按钮
	 * @param comm_name
	 * @param image1
	 * @param price
	 * @param details
	 * @param session
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("/addcart")
	@ResponseBody
	public String addCart(
			@Param("comm_name")String comm_name,
			@Param("image1")String image1,
			@Param("price")double price,
			@Param("details")String details,
			HttpSession session,HttpServletRequest request,
			HttpServletResponse response
			) throws UnsupportedEncodingException{
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		 
		int count=1;
		//String lisi="李四";
		Register_table register_table=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		if(register_table==null){
			return "NoNull";
		}
		String username=register_table.getUsername();
		//获取会话域里的用户名写进购物车里
		Cart_table cart_table=new Cart_table();
		cart_table.setUsername(username);
		cart_table.setComm_name(comm_name);
		cart_table.setImagecart(image1);
		
		cart_table.setCount(count);
		cart_table.setPrice(price);
		cart_table.setDetails(details);
		
		int index=cart_tableService.insert_Cart_table_Service(cart_table);
		System.out.println("添加购物车成功："+index);
		
		return "ERROR";
	}
	@RequestMapping("/myCartTotal")
	@ResponseBody
	public Object getMyCartTotal(HttpSession session){
		Register_table register_table=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		if(register_table==null){
			return 0;
		}
		String username=register_table.getUsername();
		//获取会话域里的用户名写进购物车里
		int total=cart_tableService.countCart_table_Service(username);
		System.out.println("查询用户名"+username+"的的购物车总数:"+total);
		return total;
	}
	
}
