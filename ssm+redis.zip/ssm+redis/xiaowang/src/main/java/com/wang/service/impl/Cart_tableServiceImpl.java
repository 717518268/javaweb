package com.wang.service.impl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wang.dao.Cart_TableDao;
import com.wang.pojo.Cart_table;
import com.wang.service.Cart_tableService;
@Service
@Transactional
public class Cart_tableServiceImpl implements Cart_tableService{
	
	@Autowired
	private Cart_TableDao cart_TableDao;
	

	/**
	 * 根据id�?
	 * @param id
	 * @return
	 */
	public Cart_table selectCart_tableById_Service(int id) {
		
		return cart_TableDao.selectCart_tableById(id);
	}
	/**
	 * 模糊查询
	 * 滚局用户名去查购物车数据表的数据
	 * @param username
	 * @return
	 */
	public List<Cart_table> findeNameCart_table_Service(String username) {
		
		return cart_TableDao.findeNameCart_table(username);
	}
	/**
	 * 删除�?个商�?
	 * @param id
	 * @return
	 */
	public int deleteByCart_tableId_Service(int id) {
		
		return cart_TableDao.deleteByCart_tableId(id);
	}
	/**
	 * 添加�?个商品进购物�?
	 * @param cart_table
	 * @return
	 */
	public int insert_Cart_table_Service(Cart_table cart_table) {
		
		return cart_TableDao.insert_Cart_table(cart_table);
	}
	/**
	 * 给当前用户添�?
	 * 添加�?个商品的进购物车
	 * @param cart_table
	 * @return
	 */
	public int insertCart_table_Service(Cart_table cart_table) {
		
		return cart_TableDao.insertCart_table(cart_table);
	}
	/**
	 * 查看自己购物车的数量
	 * @param username
	 * @return
	 */
	public int countCart_table_Service(String username) {
		
		return cart_TableDao.countCart_table(username);
	}
	/**
	 * 修改数量
	 * @param cart_table
	 * @return
	 */
	public int updateCart_table_Service(Cart_table cart_table) {
		
		return cart_TableDao.updateCart_table(cart_table);
	}
	
	/**
	 * 批量删除
	 */
	public Integer deleteByCart_tableIDS(String id) {
		
		String[] ids=id.split(",");
		 
		return cart_TableDao.deleteByCart_tableIDS(ids);
	}

}
