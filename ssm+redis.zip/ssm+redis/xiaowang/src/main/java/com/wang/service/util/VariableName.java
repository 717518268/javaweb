package com.wang.service.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.fileupload.FileItem;

import com.google.gson.Gson;
import com.qiniu.common.QiniuException;
import com.qiniu.common.Zone;
import com.qiniu.http.Response;
import com.qiniu.storage.Configuration;
import com.qiniu.storage.UploadManager;
import com.qiniu.storage.model.DefaultPutRet;
import com.qiniu.util.Auth;

/**
 * 七牛云存储
 * 本地
 * @author Administrator
 *
 */
public class VariableName {
	 /**基本配置-从七牛管理后台拿到*/ 
	  //设置好账号的ACCESS_KEY和SECRET_KEY  
	public static final  String ACCESS_KEY = "YfuyYh69q7W_U8DtdlznbI8M51EkrQHixmVQLFVQ";  
	public static final String SECRET_KEY = "YSKrNkwCgYMMCbD4sm0g6p4kH58BLuuxRDlNfpnu";  
	  //要上传的空间名--  
	public static final  String bucketname = "wangweiquan";  
//  七牛默认域名
	public static final String domain = "http://dreamwang.com.cn";
	  /**指定保存到七牛的文件名--同名上传会报错  {"error":"file exists"}*/ 
	  /** {"hash":"FrQF5eX_kNsNKwgGNeJ4TbBA0Xzr","key":"aa1.jpg"} 正常返回 key为七牛空间地址 http:/xxxx.com/aa1.jpg */ 
	
	//上传到七牛后保存的文件名    访问为：https://oswj11a86.bkt.clouddn.com/daimo6.png
	
	  //密钥配置  
	 Auth   auth = Auth.create(ACCESS_KEY, SECRET_KEY);  
	  //创建上传对象  
	   UploadManager uploadManager =new UploadManager(new Configuration(Zone.zone2())); 
	  //简单上传，使用默认策略，只需要设置上传的空间名就可以了  
	  public   String getUpToken(){  
	      return auth.uploadToken(bucketname);  
	  }  
	   //传文件名字进来，第二个key是保存的名字为
	  public  void upload(String FilePath,String key) throws IOException{  
	    try {  
	      //调用put方法上传  
	       System.out.println(FilePath);
	      Response res = uploadManager.put(FilePath, key, getUpToken());  
	      //打印返回的信息  
	      System.out.println(res.bodyString());  
	      System.out.println(res.statusCode);//200为上传成功
	      } catch (QiniuException e) {  
	          Response r = e.response;  
	          // 请求失败时打印的异常的信息  
	          System.out.println(r.toString());  
	          try {  
	              //响应的文本信息  
	            System.out.println(r.bodyString());  
	          } catch (QiniuException e1) {  
	              //ignore  
	          }  
	      }         
	  }  
	   
	  
	  

	  
		@SuppressWarnings("unused")
		public  void uploadToQiNiuYun(HashMap<String, FileItem> files) throws IOException {
			//构造一个带指定Zone对象的配置类
			System.out.println("=================七牛云=======================");
			Configuration cfg = new Configuration(Zone.zone2());
			//...其他参数参考类注释
//			华东	Zone.zone0()
//			华北	Zone.zone1()
//			华南	Zone.zone2()
//			北美	Zone.zoneNa0()
	 
			UploadManager uploadManager = new UploadManager(cfg);
			//...生成上传凭证，然后准备上传
			String accessKey = "YfuyYh69q7W_U8DtdlznbI8M51EkrQHixmVQLFVQ";//这里请替换成自己的AK
			String secretKey = "YSKrNkwCgYMMCbD4sm0g6p4kH58BLuuxRDlNfpnu";//这里请替换成自己的SK
			String bucket = "wangweiquan";//这里请替换成自己的bucket--空间名
	 
			//默认不指定key的情况下，以文件内容的hash值作为文件名
			String key = null;
	 
			
			 Iterator iter = files.entrySet().iterator();  
	         int i=0;  
	         while (iter.hasNext()) {  
	             i++;  
	             Map.Entry entry = (Map.Entry) iter.next();  
	             String fileName = (String) entry.getKey();  
	             FileItem val = (FileItem) entry.getValue();
	             InputStream inputStream=val.getInputStream();
	             ByteArrayOutputStream swapStream = new ByteArrayOutputStream(); 
	             byte[] buff = new byte[600]; //buff用于存放循环读取的临时数据 
	             int rc = 0; 
	             while ((rc = inputStream.read(buff, 0, 100)) > 0) { 
	             swapStream.write(buff, 0, rc); 
	             } 
	             byte[] uploadBytes  = swapStream.toByteArray(); //uploadBytes 为转换之后的结果 
	             Auth auth = Auth.create(accessKey, secretKey);
				String upToken = auth.uploadToken(bucket);
				try {
				    Response response = uploadManager.put(uploadBytes, key, upToken);
				    //解析上传成功的结果
				    DefaultPutRet putRet = new Gson().fromJson(response.bodyString(), DefaultPutRet.class);
				    System.out.println(putRet.key);
				    System.out.println(putRet.hash);
				} catch (QiniuException ex) {
				    Response r = ex.response;
				    System.err.println(r.toString());
				    try {
				        System.err.println(r.bodyString());
				    } catch (QiniuException ex2) {
				        //ignore
				    }
				}
	         }
			
			
		
			
		}  

	 
	  
	  
	  
	  
	  
}
