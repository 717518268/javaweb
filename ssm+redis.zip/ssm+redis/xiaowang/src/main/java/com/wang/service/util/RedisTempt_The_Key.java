package com.wang.service.util;

public class RedisTempt_The_Key {
	/**
	 * 用户对象key
	 */
	public static final String USER="register_table";
	
	public static String USERINFO(String username){
		String info=USER+username;
		return info;
	}
	
	
}
