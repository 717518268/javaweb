package com.wang.service.impl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wang.dao.Register_TableDao;
import com.wang.service.Register_TableService;
import com.wang.pojo.Register_table;
@Service
@Transactional
public class Register_TableServiceImpl implements Register_TableService{
	
	@Autowired
	private Register_TableDao register_TableDao;
	/**
	 * 查所有
	 * @return
	 */
	public List<Register_table> selectRegisterAll_Service() {
		
		return register_TableDao.selectRegisterAll();
	}
	/**
	 * 登录
	 * @param register_table
	 * @return
	 */
	public Register_table selectREgister_Username_Password_Service(Register_table register_table) {
		
		return register_TableDao.selectREgister_Username_Password(register_table);
	}
	/**
	 * 根据id查询对象
	 * @param id
	 * @return
	 */
	public Register_table selectByRegisterId_Service(Integer id) {
		
		return register_TableDao.selectByRegisterId(id);
	}
	/**
	 * 根据id删除
	 * @param id
	 * @return
	 */
	public int deleteRegister_table_Service(Integer id) {
		
		return register_TableDao.deleteRegister_table(id);
	}
	/**
	 * 插入一个
	 * @param register_table
	 * @return
	 */
	public int insertREgister_Service(Register_table register_table) {
		
		return register_TableDao.insertREgister(register_table);
	}
	/**
	 * 动态SQL插入
	 * @param register_table
	 * @return
	 */
	public int insertSQLRegister_table_Service(Register_table register_table) {
		
		return register_TableDao.insertSQLRegister_table(register_table);
	}
	/**
	 * 查询总数
	 * @return
	 */
	public int countRegister_table_Service() {
		
		return register_TableDao.countRegister_table();
	}
	/**
	 * 修改个人信息
	 * 动态SQL
	 * @param register_table
	 * @return
	 */
	public int updateSQLRegister_table5_Service(Register_table register_table) {
		
		return register_TableDao.updateSQLRegister_table5(register_table);
	}
	/**
	 * 修改个人信息
	 * @param register_table
	 * @return
	 */
	public int updateRegister_table5_Service(Register_table register_table) {
		
		return register_TableDao.updateRegister_table5(register_table);
	}
	/**
	 * 验证账号是否相同
	 * @param username
	 * @return
	 */
	public Integer selectR_Username_Service(String username) {
		
		return register_TableDao.selectR_Username(username);
	}
	public Register_table Selectregister_address_table_Service(String username) {
		 
		return register_TableDao.Selectregister_address_table(username);
	}
	
	/**
	 * 用于绑定本地账号
	 */
	public int updateRegister_table_WeixinLogin_Serivce(Register_table register_table) {
		// TODO Auto-generated method stub
		return register_TableDao.updateRegister_table_WeixinLogin(register_table);
	}
	
	/**
	 * 微信登录情况下进行插入
	 */
	public Register_table selectR_Username_Weixin_Serivce(Register_table register_table) {
		// TODO Auto-generated method stub
		return register_TableDao.selectR_Username_Weixin(register_table);
	}
	
	/**
	 * 注册
	 */
	public int insertREgisterOneby(Register_table register_table) {
		
		return register_TableDao.insertREgisterOneby(register_table);
	}
	
	
	/**
	 * 验证账号
	 */
	public String selectR_Username_Service2(String username) {
		
		return register_TableDao.selectR_Username_Service2(username);
	}
	
	/**
	 * 批量删除
	 * 服务层操作
	 */
	public int deleteAllChexBoxMap(String id) {
		// TODO Auto-generated method stub
		String []ids=id.split(",");//进行逗号字符分割
	 
	 
		int IndexDeleteValue=register_TableDao.deleteAllChexBoxMap(ids);
		 
		return IndexDeleteValue;
	}
	 
}
