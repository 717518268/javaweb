package com.wang.pojo;

import java.io.Serializable;

public class Weixin_table implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5364266260184694625L;
	
	private Integer id;
	private String openid;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getOpenid() {
		return openid;
	}
	public void setOpenid(String openid) {
		this.openid = openid;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((openid == null) ? 0 : openid.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Weixin_table other = (Weixin_table) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (openid == null) {
			if (other.openid != null)
				return false;
		} else if (!openid.equals(other.openid))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Weixin_table [id=" + id + ", openid=" + openid + "]";
	}
	public Weixin_table(String openid) {
		
		this.openid = openid;
	}
	public Weixin_table() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
