package com.wang.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wang.dao.Weixin_tableDao;
import com.wang.pojo.Weixin_table;
import com.wang.service.Weixin_tableService;
/**
 * 微信登录实现类
 * @author Administrator
 *
 */
@Service
@Transactional
public class Weixin_tableServiceImpl implements Weixin_tableService{
	@Autowired
	private Weixin_tableDao weixin_tableDao;
	
	public int insertOpendids_Service(Weixin_table weixin_table) {
		// TODO Auto-generated method stub
		return weixin_tableDao.insertOpendids(weixin_table);
	}
	/**
	 * 查询微信openid
	 */
	public Weixin_table selectGetNameOpenidCount_Service(String openid) {
		// TODO Auto-generated method stub
		return weixin_tableDao.selectGetNameOpenidCount(openid);
	}
	/**
	 * 查所有的微信id
	 */
	public List<Weixin_table> selectALLOpenid_Service() {
		
		return weixin_tableDao.selectALLOpenid();
	}

}
