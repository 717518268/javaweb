package com.wang.service.impl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wang.dao.Main_tableDao;
import com.wang.pojo.Main_table;
import com.wang.service.Main_tableService;

/**
 * 主页的数据表参数	（main_table�?	浏览数据（设置物品分类）
 * @author Administrator
 *
 */
@Service
@Transactional
public class Main_tableDaoimpl implements Main_tableService{
	
	@Autowired
	private Main_tableDao main_tableDao;
	/**
	 * 插入
	 */
	public int insertMain_tabledaoService(Main_table main_table) {
		
		return main_tableDao.insertMain_tabledao(main_table);
	}
	/**
	 * 插入
	 */
	public int insertMain_tableSelectiveService(Main_table main_table) {
		
		return main_tableDao.insertMain_tableSelective(main_table);
	}

	/**
	 * 查询�?�?
	 */
	public List<Main_table> selectByMain_tableService() {
		
		return main_tableDao.selectByMain_table();
	}
	/**
	 * 根据id查询�?个对�?
	 */
	public Main_table selectByMain_tableKeyService(Integer id) {
		
		return main_tableDao.selectByMain_tableKey(id);
	}
	/**
	 * 查�?�数
	 */
	public int selectcountByMain_tableService() {
		
		return main_tableDao.selectcountByMain_table();
	}
	/**
	 * 更改
	 */
	public int updateByKeySelective5Service(Main_table main_table) {
		
		return main_tableDao.updateByKeySelective5(main_table);
	}
	/**
	 * 修改5个字�?
	 */
	public int UpdateMain_table5(Main_table main_table) {
		
		return main_tableDao.UpdateMain_table5(main_table);
	}
	/**
	 * 修改三个字段
	 */
	public int updateByPrimaryKey3Service(Main_table main_table) {
		
		return main_tableDao.updateByPrimaryKey3(main_table);
	}
	/**
	 * 删除
	 */
	public int deleteByPrimaryKeyIDService(Integer main_id) {
		
		return main_tableDao.deleteByPrimaryKeyID(main_id);
	}
	public int updateByCountAccess(Main_table main_table) {
		// TODO Auto-generated method stub
		return main_tableDao.updateByCountAccess(main_table);
	}
	
	
	
}
