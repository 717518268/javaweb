package com.wang.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.Register_table;
import com.wang.service.Register_TableService;
import com.wang.service.util.GetDate;
import com.wang.service.util.GetMD5;

@Controller
public class registerController {
	
	@Autowired
	private Register_TableService register_TableService;
	 
	/** 
	 * 请求到注册页
	 * @return
	 */
	@RequestMapping("/register")
	public String registyThis(){
		
		return "register";
	}
	 
	
	 
	
	/**
	 * 插入数据
	 * @param request
	 * @param username
	 * @param password
	 * @param sex
	 * @return
	 */
	@RequestMapping("/insertRegsiter")
	@ResponseBody
	public Object inserTORegisTAble(
			 
			@Param("username")String username,
			@Param("password")String password,
			@Param("code")String code
			 ,HttpServletRequest request
			){
		System.out.println("进行账号参数："+username);
		System.out.println("进行密码参数："+password);
	
		String codeSession=request.getSession().getAttribute("code").toString();
		if(code.equalsIgnoreCase(codeSession)){
			System.out.println("验证结果："+code.equalsIgnoreCase(codeSession));
			//用户名是否重复
			int registerUserName= register_TableService.selectR_Username_Service(username);
			System.out.println("数据是否存有用户值："+registerUserName);
			if(registerUserName==0){//没有注册过的情况下
				//进行空值判断
				String time=GetDate.getdate();
				
				password=GetMD5.encodeToHex(password);
				//MD5加密
				Register_table register_table=new Register_table();
				register_table.setUsername(username);
				register_table.setPassword(password);
				register_table.setSex("无");
				register_table.setTime(time);
				//向数据库插入4个字段
				int index=register_TableService.insertREgisterOneby(register_table);
				 
				if(index>0){//插入成功之后返回的是1
					System.out.println("注册！！添加数据成功！！！");
					return "SUCCESS";
				}
			}else{
				//注册过的情况下返回HaveValue
				System.out.println("注册过的情况下返回HaveValue");
				return "HaveValue";
			}
		}else{
			//返回验证码错误
			return "CODEERROR";
		}
			 
		
	 
		 
		
		return "ERROR";
	}
	
	
	
	
	
	
}
