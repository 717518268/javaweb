package com.wang.dao;

import java.util.List;

import com.wang.pojo.Cart_table;

public interface Cart_TableDao {
	
	/**
	 * 根据id查
	 * @param id
	 * @return
	 */
    public Cart_table	selectCart_tableById(int id);
    /**
	 * 模糊查询
	 * 滚局用户名去查购物车数据表的数据
	 * @param username
	 * @return
	 */
	public List<Cart_table>findeNameCart_table(String username);
	
	/**
	 * 删除一个商品
	 * @param id
	 * @return
	 */
	public int deleteByCart_tableId(int id);
	
	/**
	 * 购物车批量删除
	 * @param id
	 * @return
	 */
	public Integer deleteByCart_tableIDS(String []id);
	/**
	 * 添加一个商品进购物车
	 * @param cart_table
	 * @return
	 */
	public int insert_Cart_table(Cart_table cart_table);
	
	/**
	 * 给当前用户添加
	 * 添加一个商品的进购物车
	 * @param cart_table
	 * @return
	 */
	public int insertCart_table(Cart_table cart_table);
	
	/**
	 * 查看自己购物车的数量
	 * @param username
	 * @return
	 */
	public int countCart_table(String username);
	/**
	 * 修改数量
	 * @param cart_table
	 * @return
	 */
	public int updateCart_table(Cart_table cart_table);
}
