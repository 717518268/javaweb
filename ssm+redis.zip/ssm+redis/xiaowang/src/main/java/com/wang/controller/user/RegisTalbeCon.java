package com.wang.controller.user;

import java.util.List;



import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.annotations.Param;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
 
import com.wang.pojo.Commodity_table;
import com.wang.pojo.Register_table;
import com.wang.service.Register_TableService;
@SuppressWarnings("all")
@Controller
public class RegisTalbeCon {
	@Autowired
	private Register_TableService register_TableService;
	 
	@Autowired
	private RedisTemplate redisTemplate;
	/**
	 * 把大数据写进缓存里
	 * @return
	 */
	 
	@RequestMapping("/getRegisAllList")
	 @ResponseBody
	public List<Register_table> getRegist(){
		/*System.out.println("进入用户分页");
		PageHelper.startPage(pn1,5);
		List<Register_table>list= list=register_TableService.selectRegisterAll_Service();
		PageInfo<Register_table>page=new PageInfo<>(list, 4);
		request.setAttribute("pageinfoRegister",page);*/
		List<Register_table>list=(List<Register_table>) redisTemplate.opsForValue().get("registable");
		if(list==null){
			 list=register_TableService.selectRegisterAll_Service();
			 redisTemplate.opsForValue().set("registable",list ,1,TimeUnit.HOURS );
			 //写进缓存
		}
		
		return list;
	}
	/**
	 * 删除用户操作id
	 * 单个
	 * @param id
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping("/deleteRegisOneContext")
	@ResponseBody
	public Object deleyeRegisTable(@Param("id")Integer id){
		
		
		int deleteindex=register_TableService.deleteRegister_table_Service(id);
		if(deleteindex>0){
			//删除成功，清空redis
			redisTemplate.delete("registable");
		}
		/**
		 * 清空缓存
		 */
	
		return deleteindex;
	}
	
	/**
	 * 批量删除
	 * @param id
	 * @return
	 */
	@RequestMapping("deleteAll/UserChexBoxIds")
	@ResponseBody
	public String deleteByAllChexBox(@Param("id")String id){
		
		//服务层进行分割id
		register_TableService.deleteAllChexBoxMap(id);
		redisTemplate.delete("registable");
		return "ok";
	}
	
	
	
	
}
