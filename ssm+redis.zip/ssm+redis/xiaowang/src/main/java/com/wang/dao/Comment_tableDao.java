package com.wang.dao;

import java.util.List;

import com.wang.pojo.Comment_table;
/**
 * 全局评论数据表
 * 评论接口
 * @author Administrator
 *
 */
public interface Comment_tableDao {
	/**
	 * 查询所有的评论信息
	 * @return
	 */
	public List<Comment_table>selectByComment_table(Comment_table comment_table);
	/**
	 * 查询自己所有的评论信息
	 * @return
	 */
	public List<Comment_table>selectBymyselListComment_table(Comment_table comment_table);
	/**
	 * 根据id查询评论信息
	 * @param cid
	 * @return
	 */
	public Comment_table selectByComment_tableID(Integer cid);
	/**
	 * 删除一条
	 *  delete from comment_table
    where cid= #{cid,jdbcType=INTEGER}
	 * @param cid
	 * @return
	 */
	public int deleteByComment_table(Integer cid);
	/**
	 * 批量删除
	 *    <!-- 
    批量删除 
    -->
  <delete id="deleteComment_tableIds" parameterType="java.lang.String">
    delete from comment_table where id in
  <foreach item="cid" collection="array" index="no" open="(" separator="," close=")">
  #{cid}
  </foreach>
  </delete>
	 * @param cid
	 * @return
	 */
	public int deleteComment_tableIds(String []cid);
	
	/**
	 * 添加一条评论
	 * @param comment_table
	 * @return
	 */
	public int insertComment_table(Comment_table comment_table);
	/***
	 * 动态sQL插入评论
	 * @param comment_table
	 * @return
	 */
	public int insertSQLComment_table(Comment_table comment_table);
	/**
	 * 根据商品查询评论信息
	 * @param name
	 * @return
	 */
	public Integer Comment_tablecount(String name);
	
	/**
	 * 点赞修改
	 * 只需要注入一个参数praise
	 * @param comment_table
	 * @return
	 */
	public Integer updatePraiseComment_table(Comment_table comment_table);
	
}
