package com.wang.controller.user;

import java.io.File;


import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.annotations.Param;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.qiniu.util.StringMap;
 
import com.wang.pojo.Address_table;
import com.wang.pojo.Commodity_table;
import com.wang.pojo.Register_table;
import com.wang.service.Address_tableService;
import com.wang.service.Commodity_tableService;
import com.wang.service.Order_tableService;
import com.wang.service.Register_TableService;
import com.wang.service.util.GetDate;
import com.wang.service.util.QiniuUtil;
import com.wang.service.util.VariableName;
/**
 * 管理后台控制器
 * @author Administrator
 *
 */
@Controller
public class AdminUserController {
	
	@Autowired
	private Register_TableService register_TableService;
	@Autowired
	private Commodity_tableService commodity_tableService;
	@Autowired
	private RedisTemplate redisTemplate;
	
	 
	/**
	 * 进入视图
	 * @return
	 */
	@RequestMapping("/AdminUser")
	public String getAdminModelAndView(){
		//主用户视图
		return "AdminUser";
	}
	
	/**
	 * 获取用户量的总数
	 * @return
	 */
	@RequestMapping("/getRegisTerTotal")
	@ResponseBody
	public Object getRegisterTotal(){
		//查询用户总数
		int index=register_TableService.countRegister_table_Service();
		return index;
	}
	
	
	
	/**
	 * 商品添加的
	 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping("/adminAddInser")
	public String getToinsertComment(
	@Param("title")String title,@Param("name")String name,@Param("origin")String origin,
	@Param("count")int count,@Param("price")Double price,@Param("details")String details,
	MultipartFile image1,MultipartFile image2,MultipartFile image3,MultipartFile image4,MultipartFile image5,
	HttpServletRequest request){
		/*id自增,标题,商品名字,省份,数量,价格,商品详情,时间参数*/
		String time= GetDate.getdate();
		//刚添加所以设置为零
		int commoditycount=0;
		 
		 String fileName1 = image1.getOriginalFilename();	
		 String truename1="image/categorypage/"+fileName1;
		 
		 String fileName2 = image2.getOriginalFilename();	
		 String truename2="image/categorypage/"+fileName2;
		 
		 
		 String fileName3 = image2.getOriginalFilename();	
		 String truename3="image/categorypage/"+fileName3;
		 String fileName4 = image2.getOriginalFilename();
		 String truename4="image/categorypage/"+fileName4;
		 String fileName5 = image2.getOriginalFilename();
		 String truename5="image/categorypage/"+fileName5;
		 truename2+=","+truename3+","+truename4+","+truename4+",";
		 
		Commodity_table commodity_table=new Commodity_table(title, name, count, price, truename1, truename2, origin, details, time, commoditycount);
		System.out.println(commodity_table);
		 String path=request.getSession().getServletContext().getRealPath("/image/categorypage");
		//商品文件夹是/image/categorypage
		commodity_tableService.insertCommont_table_Service(commodity_table);
		redisTemplate.delete("Comm_List");
		//删除缓存的键
		 File file=new File(path);
			//判断路径是否存在
			if(!file.exists()){
				//创建文件
				file.mkdirs();
				
			}
			try {
				 
				image1.transferTo(new File(path,fileName1));
				image2.transferTo(new File(path,fileName2));
				image3.transferTo(new File(path,fileName3));
				image4.transferTo(new File(path,fileName4));
				image4.transferTo(new File(path,fileName5));
				 
				// File destFile = new File(path + "/" + fileName1);
		         //简单方式上传到七牛云服务器
	            
					StringMap stringMap1 = QiniuUtil.upload(fileName1, path + "/" + fileName1);
				 
	             StringMap stringMap2= QiniuUtil.upload(fileName2, path + "/" + fileName2);
	             StringMap stringMap3= QiniuUtil.upload(fileName3, path + "/" + fileName3);
	             StringMap stringMap4= QiniuUtil.upload(fileName4, path + "/" + fileName4);
	             StringMap stringMap5= QiniuUtil.upload(fileName4, path + "/" + fileName5);
	             } catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
				
				 
			finally {
				
			}
			
		return "adminSuccess";
	}
	
	 
	
	 
	
}
