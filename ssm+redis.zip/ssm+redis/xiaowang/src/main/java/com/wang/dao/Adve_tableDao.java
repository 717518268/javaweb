package com.wang.dao;

import java.util.List;

import com.wang.pojo.Adve_table;

public interface Adve_tableDao {
	
	/**
	 * 查所有
	 *   select * from adve_table
	 * @return
	 */
	public List<Adve_table>selectAdve_atbleAll();
	/**
	 * 根据id查询
	 *  select * from adve_table
    where adve_id = #{adve_id,jdbcType=INTEGER}
	 * @param adve_id
	 * @return
	 */
	public Adve_table selectadve_tableById(Integer adve_id);
	
	/**
	 * 查总数
	 * @return
	 */
	public Integer countadve_tabkle();
	
	/**
	 * 插入一条广告
	 *   insert into adve_table (adve_title,adve_image,
    adve_describe, 
      adve_content, 
      adve_time, adve_count
     )
    values (
     #{adve_title,jdbcType=VARCHAR}, 
      #{adve_image,jdbcType=LONGVARCHAR}, 
     #{adve_describe,jdbcType=VARCHAR}, 
      #{adve_content,jdbcType=LONGVARCHAR},
      #{adve_time,jdbcType=VARCHAR}, 
      #{adve_count,jdbcType=INTEGER}
     )
	 * @param adve_table
	 * @return
	 */
	public int insertAdve_table(Adve_table adve_table);
	

	/**
	 * 根据id修改
	 *  update adve_table
    set adve_title = #{adve_title,jdbcType=VARCHAR},
     adve_image = #{adve_image,jdbcType=LONGVARCHAR},
      adve_describe = #{adve_describe,jdbcType=VARCHAR},  
       adve_content = #{adve_content,jdbcType=LONGVARCHAR},
       adve_time = #{adve_time,jdbcType=VARCHAR},
      adve_count = #{adve_count,jdbcType=INTEGER}
    where adve_id = #{adve_id,jdbcType=INTEGER}
	 * @param adve_table
	 * @return
	 */
	public int updatesAdve_TableId(Adve_table adve_table);

	/**
	 * 根据id修改SQL
	 * @param adve_id
	 * @return
	 */
	public int  updateBYIdSQL(Adve_table adve_table);
	
	/**
	 * 根据id删除
	 * delete from adve_table
    	where adve_id = #{adve_id,jdbcType=INTEGER}
	 * @param adve_id
	 * @return
	 */
	public int deleteAdve_tablrBYID(Integer adve_id);
	
	/**
	 * 删除 
	 *  
  <delete id="deleteAdve_tablrBYID" parameterType="com.wang.pojo.Adve_table" >
  
    delete from adve_table where adve_id=#{adve_id}
  </delete>
	 * @param adve_id
	 * @return
	 */
	public int deleteAdVeBKey(Integer adve_id);
	
	/**
	 * 批量删除
	 * 
	 *  <!-- 批量删除 -->
  <delete id="DeleteAll_IDS_Chexbox_Adve_table" parameterType="java.lang.String">
    delete from adve_table where adve_id in
  <foreach item="adve_id" collection="array" index="no" open="(" separator="," close=")">
  #{adve_id}
  </foreach>
  </delete>
	 * @param adve_id
	 * @return
	 */
	public int DeleteAll_IDS_Chexbox_Adve_table(String[]adve_id);
}
