package com.wang.service.util;

import java.io.IOException;
import java.util.logging.Logger;

import org.apache.log4j.spi.LoggerFactory;

import com.qiniu.common.QiniuException;
import com.qiniu.common.Zone;
import com.qiniu.http.Response;
import com.qiniu.storage.Configuration;
import com.qiniu.storage.UploadManager;
import com.qiniu.util.Auth;
import com.qiniu.util.StringMap;
/**
 * 七牛云上传工具类
 * @author Administrator
 *
 */
public class QiniuUtil {
	 

	    //设置好账号的ACCESS_KEY和SECRET_KEY
	    private static final String ACCESS_KEY ="YfuyYh69q7W_U8DtdlznbI8M51EkrQHixmVQLFVQ";
	    private static final String SECRET_KEY ="YSKrNkwCgYMMCbD4sm0g6p4kH58BLuuxRDlNfpnu";
	    //要上传的空间
	    private static final String bucketname ="wangweiquan";
	    //密钥配置
	    private static final Auth auth = Auth.create(ACCESS_KEY, SECRET_KEY);
	    private static final Zone z = Zone.autoZone();
	    private static final Configuration c = new Configuration(z);

	    //创建上传对象
	    private static UploadManager uploadManager = new UploadManager(c);

	    //简单上传，使用默认策略，只需要设置上传的空间名就可以了
	    private static String getUpToken() {
	        return auth.uploadToken(bucketname);
	    }

	    /**
	     * 七牛云上传文件
	     *
	     * @param fileName 上传后的文件名
	     * @param filePath 上传的文件名路径
	     * @return
	     * @throws IOException
	     */
	    public static StringMap upload(String fileName, String filePath) throws IOException {
	        try {
	            //调用put方法上传
	            Response res = uploadManager.put(filePath, fileName, getUpToken());
	            //打印返回的信息
	            return res.jsonToMap();
	        } catch (QiniuException e) {
	            Response r = e.response;
	            // 请求失败时打印的异常的信息
	         
	         
	        }
			return null;
	    }
}
