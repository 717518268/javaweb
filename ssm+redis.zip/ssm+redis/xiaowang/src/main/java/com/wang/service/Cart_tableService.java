package com.wang.service;

import java.util.List;



import com.wang.pojo.Cart_table;
/**
 * 购物车数据表（cart_table�??:	7个字�??
 * @author Administrator
 *
 */
public interface Cart_tableService {

	/**
	 * 根据id�??
	 * @param id
	 * @return
	 */
    public Cart_table	selectCart_tableById_Service(int id);
	/**
	 * 模糊查询
	 * 滚局用户名去查购物车数据表的数据
	 * @param username
	 * @return
	 */
	public List<Cart_table>findeNameCart_table_Service(String username);
	
	/**
	 * 删除�??个商�??
	 * @param id
	 * @return
	 */
	public int deleteByCart_tableId_Service(int id);
	
	/**
	 * 服务层进行批量删除解释
	 * @param id
	 * @return
	 */
	public Integer deleteByCart_tableIDS(String id);
	
	/**
	 * 添加�??个商品进购物�??
	 * @param cart_table
	 * @return
	 */
	public int insert_Cart_table_Service(Cart_table cart_table);
	
	/**
	 * 给当前用户添�??
	 * 添加�??个商品的进购物车
	 * @param cart_table
	 * @return
	 */
	public int insertCart_table_Service(Cart_table cart_table);
	
	/**
	 * 查看自己购物车的数量
	 * @param username
	 * @return
	 */
	public int countCart_table_Service(String username);
	/**
	 * 修改数量
	 * @param cart_table
	 * @return
	 */
	public int updateCart_table_Service(Cart_table cart_table);
	
	
}
