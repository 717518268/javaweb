package com.wang.service.util;

public class ImageSplit {
	
	
	
	public static String[] getstr(String str){
		
		
		String[] mathce=str.split(",");
		/*for (int i = 0; i < mathce.length; i++) {
			System.out.println(mathce[i]);
		}*/
		return mathce;
	}
}
