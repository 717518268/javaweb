package com.wang.service;

import java.util.List;

import com.wang.pojo.Register_table;

public interface Register_TableService {
	/**
	 * 验证账号是否相同
	 * @param username
	 * @return
	 */
	public Integer selectR_Username_Service(String username);
	
	/**
	 * 验证账号是否相同
	 * @param username
	 * @return
	 */
	public String selectR_Username_Service2(String username);
	
	public Register_table Selectregister_address_table_Service(String username);
	
	
	public int insertREgisterOneby(Register_table register_table);
	/**
	 * 查询是否已经绑定了微信id'
	 * @param register_table
	 * @return
	 */
	public Register_table selectR_Username_Weixin_Serivce(Register_table register_table);
	/**
	 * 查所有
	 * @return
	 */
	public List<Register_table>selectRegisterAll_Service();
	/**
	 * 登录
	 * @param register_table
	 * @return
	 */
	public Register_table selectREgister_Username_Password_Service(Register_table register_table);
	/**
	 * 根据id查询对象
	 * @param id
	 * @return
	 */
	public Register_table selectByRegisterId_Service(Integer id);
	
	/**
	 * 根据id删除
	 * @param id
	 * @return
	 */
	public int deleteRegister_table_Service(Integer id);
	/**
	 * 插入一个
	 * @param register_table
	 * @return
	 */
	public int insertREgister_Service(Register_table register_table);
	
	/**
	 * 动态SQL插入
	 * @param register_table
	 * @return
	 */
	public int insertSQLRegister_table_Service(Register_table register_table);
	
	/**
	 * 查询总数
	 * @return
	 */
	public int countRegister_table_Service();
	/**
	 * 修改个人信息
	 * 动态SQL
	 * @param register_table
	 * @return
	 */
	public int updateSQLRegister_table5_Service(Register_table register_table);
	/**
	 * 修改个人信息
	 * @param register_table
	 * @return
	 */
	public int updateRegister_table5_Service(Register_table register_table);
	
	/**
	 * 将微信绑定到本地账号
	 * @param register_table
	 * @return
	 */
	public int updateRegister_table_WeixinLogin_Serivce(Register_table register_table);
	
	/**
	 * 批量删除
	 * @param id
	 * @return
	 */
	public int deleteAllChexBoxMap(String id );
}
