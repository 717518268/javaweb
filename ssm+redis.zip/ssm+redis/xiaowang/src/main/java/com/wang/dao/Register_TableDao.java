package com.wang.dao;

import java.util.List;


 
import com.wang.pojo.Register_table;

public interface Register_TableDao {
	/**
	 * 验证账号是否相同
	 *   select 
    username
    from register_table 
    where username=#{username,jdbcType=VARCHAR} 
   
   
	 * @param username
	 * @return
	 */
	public Integer selectR_Username(String username);
	/**
	 * 查询是否已经绑定了微信id'
	 * @param register_table
	 * @return
	 */
	public Register_table selectR_Username_Weixin(Register_table register_table);
	/**
	 * 查所有
	 * <select id="selectRegisterAll" resultType="com.wang.pojo.Register_table">
  select  
  <include refid="Base_Column_List" />
  from register_table
  </select>
	 * @return
	 */
	public List<Register_table>selectRegisterAll();
	/**
	 * 登录
	 *  
    select 
    <include refid="Base_Column_List" />
    from register_table 
    where username=#{username,jdbcType=VARCHAR} 
    and password=#{password,jdbcType=VARCHAR}
	 * @param register_table
	 * @return
	 */
	public Register_table selectREgister_Username_Password(Register_table register_table);
	/**
	 * 根据id查询对象
	 * @param id
	 * @return
	 */
	public Register_table selectByRegisterId(Integer id);
	
	/**
	 * 根据id删除
	 *  delete from register_table
    where id = #{id,jdbcType=INTEGER}
	 * @param id
	 * @return
	 */
	public int deleteRegister_table(Integer id);
	/**
	 * 插入一个
	 * @param register_table
	 * @return
	 */
	public int insertREgister(Register_table register_table);
	
	/**
	 * 动态SQL插入
	 * @param register_table
	 * @return
	 */
	public int insertSQLRegister_table(Register_table register_table);
	
	/**
	 *   insert into register_table (username, 
      password, time)
    values ( 
    #{username,jdbcType=VARCHAR}, 
      #{password,jdbcType=VARCHAR},
     
       #{time,jdbcType=VARCHAR}
      )
	 * @param register_table
	 * @return
	 */
	public int insertREgisterOneby(Register_table register_table);
	 
	/**
	 * 查询总数
	 * select count(*) from register_table
	 * @return
	 */
	public int countRegister_table();
	/**
	 * 修改个人信息
	 * 动态SQL
	 * @param register_table
	 * @return
	 */
	public int updateSQLRegister_table5(Register_table register_table);
	/**
	 * 修改个人信息
	 * 
	 *  update register_table
    set nickname = #{nickname,jdbcType=VARCHAR},
     
      sex = #{sex,jdbcType=VARCHAR},
     
      headimage = #{headimage,jdbcType=LONGVARCHAR}
    where id = #{id,jdbcType=INTEGER}
	 * @param register_table
	 * @return
	 */
	public int updateRegister_table5(Register_table register_table);
	
	
	/**
	 *   select *
  from register_table r,address_table a 
  where r.username=a.username
  and r.username=#{username}
	 * @param username
	 * @return
	 */
	public Register_table Selectregister_address_table(String username);
	
	/**
	 * 将微信绑定到本地账号
	 * @param register_table
	 * @return
	 */
	public int updateRegister_table_WeixinLogin(Register_table register_table);
	
	/**
	 * select 
    username
    from register_table 
    where username=#{username,jdbcType=VARCHAR} 
   
	 * @param username
	 * @return
	 */
	public String selectR_Username_Service2(String username);
	
	
	/**
	 * 批量删除
	 *  delete from register_table where id in
		  <foreach item="id" collection="array" index="no" open="(" separator="," close=")">
		  #{id}
		  </foreach>
	 * @param id
	 * @return
	 */
	public int deleteAllChexBoxMap(String[]id );
	
	
	
}
