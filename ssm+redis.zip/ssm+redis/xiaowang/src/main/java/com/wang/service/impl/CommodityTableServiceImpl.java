package com.wang.service.impl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wang.dao.Commodity_tableDao;
import com.wang.pojo.Commodity_table;
import com.wang.service.Commodity_tableService;
/**
 * 商品数据表（commodity_table�?	12个字�?
 * @author quang
 *	id  自增
 *	time 自动生成
 */
@Service
@Transactional
public class CommodityTableServiceImpl implements Commodity_tableService{
	
	@Autowired
	private Commodity_tableDao commodity_tableDao;
	/**
	 * 模糊查询进行商品分类
	 * @param title
	 * @return
	 */
	public List<Commodity_table> selectListComm_tableTitle_Service(String title) {
		// TODO Auto-generated method stub
		return commodity_tableDao.selectListComm_tableTitle(title);
	}
	/**
	 * 查所�?
	 * @return
	 */
	public List<Commodity_table> selectListComm_table_Service() {
		// TODO Auto-generated method stub
		return commodity_tableDao.selectListComm_table();
	}
	/**
	 *	 根据id查询�?个商�?
	 * @param id
	 * @return
	 */
	public Commodity_table selectComm_atbleKeyById_Service(Integer id) {
		// TODO Auto-generated method stub
		return commodity_tableDao.selectComm_atbleKeyById(id);
	}
	/**
	 * 添加商品
	 * @param commodity_table
	 * @return
	 */
	public int insertCommont_table_Service(Commodity_table commodity_table) {
		// TODO Auto-generated method stub
		return commodity_tableDao.insertCommont_table(commodity_table);
	}
	/**
	 * 添加商品
	 * @param commodity_table
	 * @return
	 */
	public int insertSelectiveComm_table_Service(Commodity_table commodity_table) {
		// TODO Auto-generated method stub
		return commodity_tableDao.insertSelectiveComm_table(commodity_table);
	}
	/**
	 * 	查库存放进redis�?
	 * @param id
	 * @return
	 */
	public int countByExample_Service(Integer id) {
		// TODO Auto-generated method stub
		return commodity_tableDao.countByExample(id);
	}
	/**
    动�?�SQL
* @param commodity_table
* @return
*/
	public int updateBySQlSelective_Service(Commodity_table commodity_table) {
		// TODO Auto-generated method stub
		return commodity_tableDao.updateBySQlSelective(commodity_table);
	}
	/**
	 * 	除了时间不用改和id
	 * @param commodity_table
	 * @return
	 */
	public int updateComm_tableKeyAll_Service(Commodity_table commodity_table) {
		// TODO Auto-generated method stub
		return commodity_tableDao.updateComm_tableKeyAll(commodity_table);
	}
	/**
	 *	 库存减少
	 * @param commodity_table
	 * @return
	 */
	public int updateByPrimaryKeyId_Service(Commodity_table commodity_table) {
		// TODO Auto-generated method stub
		return commodity_tableDao.updateByPrimaryKeyId(commodity_table);
	}
	/**
	 * 	根据id删除�?个商�?
	 * @param id
	 * @return
	 */
	public int deleteByPrimaryKeyID_Service(Integer id) {
		// TODO Auto-generated method stub
		return commodity_tableDao.deleteByPrimaryKeyID(id);
	}
	public Commodity_table selectByOrder_tableName_Service(String name) {
		// TODO Auto-generated method stub
		return commodity_tableDao.selectComm_atbleKeyByName(name);
	}
	public int CountAllComment_Service() {
		// TODO Auto-generated method stub
		return commodity_tableDao.CountAllComment();
	}
	/**
	 * 写进访问量
	 */
	public int updateCommCountKeyId(Commodity_table commodity_table) {
		// TODO Auto-generated method stub
		return commodity_tableDao.updateCommCountKeyId(commodity_table);
	}
	public List<String> selectListComm_tableName() {
		// TODO Auto-generated method stub
		return commodity_tableDao.selectListComm_tableName();
	}
	public int updateByPrimaryKeyNameCountAuto(Commodity_table Commodity_table) {
		// TODO Auto-generated method stub
		return commodity_tableDao.updateByPrimaryKeyNameCountAuto(Commodity_table);
	}
	
	
	/**
	 * 批量删除操作
	 */
	public int deleteCommodity_tableIds(String id) {
		 
		String[] ids=id.split(",");
		int value=commodity_tableDao.deleteCommodity_tableIds(ids);
		return  value;
	}

}
