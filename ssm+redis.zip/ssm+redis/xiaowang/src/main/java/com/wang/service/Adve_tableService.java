package com.wang.service;

import java.util.List;




import com.wang.pojo.Adve_table;
/**
 * 服务层
 * @author Administrator
 *
 */
public interface Adve_tableService {
	/**
	 * 查所�??
	 * @return
	 */
	public List<Adve_table>selectAdve_atbleAllService();
	/**
	 * 根据id查询
	 * @param adve_id
	 * @return
	 */
	public Adve_table selectadve_tableByIdService(Integer adve_id);
	
	/**
	 * 查�?�数
	 * @return
	 */
	public Integer countadve_tabkleService();
	
	/**
	 * 批量id删除
	 * @param adve_id
	 * @return
	 */
	public int DeleteAll_IDS_Chexbox_Adve_table(String adve_id);
	/**
	 * 插入�??条广�??
	 * @param adve_table
	 * @return
	 */
	public int insertAdve_tableService(Adve_table adve_table);
	
	/**
	 * 根据id修改
	 * @param adve_id
	 * @return
	 */
	public int updatesAdve_TableIdService(Adve_table adve_table);

	/**
	 * 根据id修改SQL
	 * @param adve_id
	 * @return
	 */
	public int updateBYIdSQLService(Adve_table adve_table);
	
	/**
	 * 根据id删除
	 * @param adve_id
	 * @return
	 */
	public int deleteAdve_tablrBYIDService(Integer adve_id);
	
	/**
	 * 删除 
	 * @param adve_id
	 * @return
	 */
	public int deleteAdVeBKeyService(Integer adve_id);
	
	
}
