package com.wang.service.impl;

import java.util.UUID;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import com.wang.service.DistributedLockService;

import redis.clients.jedis.Jedis;
@Service
public class DistributedLockServiceImpl{
	private static final Logger LOG =  LoggerFactory.getLogger(DistributedLockServiceImpl.class);
	

  
}
