package com.wang.controller;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.Address_table;
import com.wang.pojo.Commodity_table;
import com.wang.pojo.Register_table;
import com.wang.service.Address_tableService;
import com.wang.service.Commodity_tableService;
import com.wang.service.util.ImageSplit;
import com.wang.service.util.OrderNumber;
import com.wang.service.util.RedisTempt_The_Key;

@Controller
public class orderpageviewController {
	@Autowired
	private Address_tableService address_tableService;
	@Autowired
	private Commodity_tableService commodity_tableService;
	
	
	
	//内部传值
	private volatile String names;
	 
	//设定好数组
	private volatile String[] images;
	//内部传参数
	private volatile Integer  userid;
	 
	
	private volatile String nickname;
	
 
	
	@RequestMapping("/orderpageview")
	public String detailspageviewView(@Param("id")Integer id,@Param("name")String name){
		 
		 
		 nickname=name;
	
		 userid=id;
		
		///System.out.println(address_table);
		return "orderpageview";
		
	}
	
	@RequestMapping("/isnull")
	@ResponseBody
	public String isNull(HttpSession session){
		Register_table register_table=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		if(register_table==null){
			return "No";
		}
		else{
			return "Yes";
		}
	}
	
	/**
	 * 把地址信息发送到前端
	 * @return
	 */
	@RequestMapping("/getoneaddress")
	@ResponseBody
	public Address_table getaddd(HttpSession session){
	 
		//从会话里，根据username去取地址信息
		Register_table register_table=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		String username=register_table.getUsername();
	
		Address_table address_table=address_tableService.selectByAddress_table_UserNAme(username);
		if(address_table!=null){
			return address_table;
		}else{
			return null;
		}
	 
	}
	
	/**
	 * 根据商品名字获取字段
	 * @return
	 */
	@RequestMapping("/getcomm_atble")
	@ResponseBody
	public Commodity_table getcommdity(){
		//内部传参
		Commodity_table commodity_table=commodity_tableService.selectByOrder_tableName_Service(nickname);
		names=commodity_table.getImage2();
		
	return commodity_table;
	}
	
	/**
	 * 返回图片列表
	 * @return
	 */
	@RequestMapping("/getimageListOrder")
	@ResponseBody
	public String[] getiamge(){
		//用正则表达式分割逗号
		this.images=ImageSplit.getstr(names);
		return this.images;
	}
	
	
	/**
	 * 生成订单号
	 * @return
	 */
	@RequestMapping("/getnumber")
	@ResponseBody
	public String getnumber(){
		//获取用户id生成订单号
	 
		return OrderNumber.getOrderNoByAtomic(userid.toString());
	}
	
	
	
}
