package com.wang.controller;

import java.io.File;




import java.io.IOException;
 
import java.util.List;
 
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.qiniu.util.StringMap;
import com.wang.pojo.Address_table;
import com.wang.pojo.Comment_table;
import com.wang.pojo.Order_table;
import com.wang.pojo.Register_table;
import com.wang.service.Address_tableService;
import com.wang.service.Comment_tableService;
import com.wang.service.Order_tableService;
import com.wang.service.Register_TableService;
import com.wang.service.util.GetDate;
import com.wang.service.util.QiniuUtil;
import com.wang.service.util.RedisTempt_The_Key;

/**
 * 用户个人中心控制器
 * @author Administrator
 *
 */
@Controller
public class PersonalCenterController {
	@Autowired
	private Register_TableService register_Service;//注册服务
 
	@SuppressWarnings("rawtypes")
	@Autowired
	private RedisTemplate redisTemplate;//redis
	@Autowired
	private Address_tableService address_tableService;//地址服务
	@Autowired
	private Comment_tableService comment_tableService;//评论服务
	@Autowired
	private Order_tableService order_tableService;//订单服务
	//private volatile Integer id;//内部id用来传地址的值的
	
	private ThreadLocal<Integer>id=new ThreadLocal<Integer>();
	//private volatile String myselsname;//有时候需要字符串内部传值
	
	private ThreadLocal<String>myselsname=new ThreadLocal<String>();
	/**
	 * 请求页面
	 * 方法
	 * @return
	 */
	@SuppressWarnings("all")
	@RequestMapping("/personalCenter")
	public String View(HttpSession session,Model model){
		//首先从缓存取出来
		/*Register_table register_table1=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		
		Register_table register_table= redisTemplate.opsForValue().get(RedisTempt_The_Key.USERINFO(register_table1.getUsername()));
		if(register_table!=null||register_table1!=null){
			
		}
		*/
		Register_table register_table1=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		if(register_table1==null){
			return "redirect:login";
		}
		String username=register_table1.getUsername();
	//	myselsname=username;
		//取登录值给变量用于获取评论列表的
		myselsname.set(username);
	//	id=register_table1.getId();
		id.set(register_table1.getId());
		List<Address_table>list=address_tableService.selectByPrimaryKey_Service(username);
		List<Order_table>orderlist=order_tableService.selectByNameOrder_table_Service(username);
		System.out.println("获取到的"+username+"地址列表"+list);
		model.addAttribute("addresslist", list);
		System.out.println("=======33===============印"+orderlist);
		 
		model.addAttribute("orderme", orderlist);
		/*Register_table register_table=register_Service.Selectregister_address_table_Service("422323");
		System.out.println(register_table);
		
		System.out.println(register_table.getAddress_table());
		*/
		
		return "personalCenter";
	}
	/**
	 * 去当前对象
	 * @return
	 */
	@RequestMapping("/getregister_table")
	@ResponseBody
	public Register_table getThreadContext(){
		Register_table register_table=register_Service.selectByRegisterId_Service(id.get());
		System.out.println(register_table);
		System.out.println("=================================================");
		return register_table;
		
	}
	
	@RequestMapping("/getorderMe")
	 
	public void getorderMe(HttpSession session,Model model){
	 
	}
	
	/**
	 * 添加地址的controller
	 * @param province2
	 * @param city2
	 * @param text
	 * @param phone
	 * @param address_name
	 * @param session
	 * @return
	 */
	@SuppressWarnings("all")
	@RequestMapping( "/insertAddress" )
	@ResponseBody
	public String insertaddress(
			@Param("province2")String province2,
			@Param("city2")String city2,
			@Param("text")String text,
			@Param("phone")String phone,
			@Param("address_name")String address_name,
			HttpSession session
			){
		System.out.println("ajax:"+province2);
		System.out.println("ajax:"+city2);
		System.out.println("ajax:"+text);
		System.out.println("ajax:"+phone);
		System.out.println("ajax:"+address_name);
		text=province2+city2+text;
		Register_table register_table1=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		String username=register_table1.getUsername();
		
		String data=GetDate.getdate();
		//获取日期格式
		Address_table address_table=new Address_table(address_name, text, phone, data, username);
		int index=address_tableService.insertAdresss_table_Service(address_table);
		System.out.println("地址添加成功"+index);
		redisTemplate.delete("GetAddress");
		return "SUCCESS";
	}
	/*
	 @RequestMapping("/addressMePersonal")
	@ResponseBody
	public List<Address_table>getAddressMe(HttpSession session){
		Register_table register_table1=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		String username=register_table1.getUsername();
		List<Address_table>list=address_tableService.selectByPrimaryKey_Service(username);
		System.out.println("获取到的"+username+"地址列表"+list);
		return list;
	}
	*/
	
	
	/**
	 * 删除地址id
	 * @param address_id
	 * @return
	 */
	@RequestMapping( "/deleteAddressId" )
	@ResponseBody
	public String deleteAddressIdMe(@Param("address_id")Integer address_id){
		System.out.println("获取了id"+address_id);
		
		int index=address_tableService.deleteByPrimaryKey_Service(address_id);
		System.out.println("删除成功："+index);
		return "SUCCESS";
	}
	
	
	
	/**
	 * 修改个人信息的
	 * @param headimage
	 * @param sex
	 * @param nickname
	 * @param request
	 * @return
	 * @throws IOException 
	 * @throws FileUploadException 
	 */
	@RequestMapping("/uppdateinfoMe" )
	 @SuppressWarnings("all")
	public String updateMEContext(MultipartFile headimage,
		@Param("sex")String sex,@Param("nickname")String nickname,HttpServletRequest request
			) throws IOException, FileUploadException{
	 
		//updateRegister_table5
		
		 // 获取input file对应的 name 的文件
		 if(headimage!=null&&sex!=""&&nickname!=""){
			 String path=request.getSession().getServletContext().getRealPath("/headimg");
			 String fileName = headimage.getOriginalFilename();
			
			 String truename="headimg/"+fileName;
			 //上传到headmg这个文件夹，
			 Register_table register_table=new Register_table(id.get(), nickname, sex, truename);
			 
			int index= register_Service.updateRegister_table5_Service(register_table);
			System.out.println("修改信息"+index);
			 // 上传的图片所保存在服务器上的位置
			 File file=new File(path);
				//判断路径是否存在
				if(!file.exists()){
					//创建文件
					file.mkdirs();
					
				}
				try {
 	 
					headimage.transferTo(new File(path,fileName));
					 
					File destFile = null;
				        if (!headimage.isEmpty()) {
				            try {
				                
				                
				                destFile = new File(path + "/" + fileName);
				            
				                StringMap stringMap = QiniuUtil.upload(fileName, path + "/" + fileName);
				                //七牛云上传
				                return "updateSuccess";//去到成功页面
				            } catch (Exception e) {
				                
				               
				            } finally {
				                //destFile.delete();
				            	//删除本地文件
				            }
				        }
					 
				} catch (IOException e) {
					System.out.println("出错了！！");
				 
				}
		 }
		 
		
		return "updateSuccess";
	}
	
	
	
	/**
	 * 根据id删除个人订单
	 * @param id
	 * @return
	 */
	@RequestMapping( "/deleteOrder" )
	@ResponseBody
	public Object deleteOrder_table(
			@Param("id")Integer id
			){
		 
		int deleteid=order_tableService.deleteByOrder_table_Service(id);
		 
		return deleteid;
	}
	
	/**
	 * 批量删除订单
	 * @param id
	 * @return
	 */
	@RequestMapping("/delete/deletemySelfOrder")
	@ResponseBody
	public String deleteMyOrder(@Param("id")String id){
		order_tableService.delete_ByOrder_tableAll_Ids(id);
		
		return "ok";
	}
	
	
	
	/**
	 * 获取自己的评论信息列表，在缓存里
	 * @return
	 */
	@SuppressWarnings("all")
	@RequestMapping( "/getmyself/comment" )
	@ResponseBody
	public List<Comment_table>getmyselfList(){
		 
		Comment_table comment_table=new Comment_table();
		comment_table.setUsername(this.myselsname.get());
		//注入username注册表字段
		
		//根据username注册字段查询评论列表的数据
		 
		List<Comment_table>list=(List<Comment_table>) redisTemplate.opsForValue().get("username"+this.myselsname);
		//放进缓存里
		if(list==null){//判断是否为null,如果不为null就去数据库查
			list=comment_tableService.selectBymyselListComment_table(comment_table);
		}
		
 
		return list;
	}
	
	/**
	 * 删掉自己评论过的数据
	 * @param id
	 * @return
	 */
	@SuppressWarnings("all")
	@RequestMapping( "/delete/myselfcoment" )
	@ResponseBody
	public Object deleteMyselfComent(@Param("id")Integer id){
		int indexCid=comment_tableService.deleteByComment_table_Service(id);
		redisTemplate.delete("username"+this.myselsname);
		//删除缓存
		return indexCid;
	}
	
	/**
	 * 批量删除
	 * @param cid
	 * @return
	 */
	@RequestMapping("/delete/myComentAllList")
	@ResponseBody
	public String deleteAllMySelfComent(@Param("cid")String cid){
		
		comment_tableService.deleteComment_tableIds(cid);
		return "ok";
	}
	
	
	
	
}
