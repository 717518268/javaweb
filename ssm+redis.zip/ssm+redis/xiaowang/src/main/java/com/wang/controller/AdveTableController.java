package com.wang.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.Adve_table;
import com.wang.service.Adve_tableService;
/**
 * 广告页数据控制器
 * @author Administrator
 *
 */
@Controller
public class AdveTableController {
	@Autowired
	private Adve_tableService  adve_tableService;
	
	@RequestMapping("/getAdve_table/listadve")
	@ResponseBody
	public List<Adve_table>getAllAdvie_table(){
		List<Adve_table>list=adve_tableService.selectAdve_atbleAllService();
		return list;
	}
	
	
}
