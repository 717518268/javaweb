package com.wang.pojo;

import java.io.Serializable;
/*
 * 广告数据表参数（adve_table�?		7
 */
public class Adve_table implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 555999239771453435L;
	
	private Integer adve_id;		//id

	private String adve_title;	//广告标题

	private String adve_image;	//广告图片

	private String adve_describe;	//广告�?�?

	private String adve_content;	//主体内容

	private String adve_time;	//发布时间

	private Integer adve_count;		//访问�?

	public Integer getAdve_id() {
		return adve_id;
	}

	public void setAdve_id(Integer adve_id) {
		this.adve_id = adve_id;
	}

	public String getAdve_title() {
		return adve_title;
	}

	public void setAdve_title(String adve_title) {
		this.adve_title = adve_title;
	}

	public String getAdve_image() {
		return adve_image;
	}

	public void setAdve_image(String adve_image) {
		this.adve_image = adve_image;
	}

	public String getAdve_describe() {
		return adve_describe;
	}

	public void setAdve_describe(String adve_describe) {
		this.adve_describe = adve_describe;
	}

	public String getAdve_content() {
		return adve_content;
	}

	public void setAdve_content(String adve_content) {
		this.adve_content = adve_content;
	}

	public String getAdve_time() {
		return adve_time;
	}

	public void setAdve_time(String adve_time) {
		this.adve_time = adve_time;
	}

	public Integer getAdve_count() {
		return adve_count;
	}

	public void setAdve_count(Integer adve_count) {
		this.adve_count = adve_count;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adve_content == null) ? 0 : adve_content.hashCode());
		result = prime * result + ((adve_count == null) ? 0 : adve_count.hashCode());
		result = prime * result + ((adve_describe == null) ? 0 : adve_describe.hashCode());
		result = prime * result + ((adve_id == null) ? 0 : adve_id.hashCode());
		result = prime * result + ((adve_image == null) ? 0 : adve_image.hashCode());
		result = prime * result + ((adve_time == null) ? 0 : adve_time.hashCode());
		result = prime * result + ((adve_title == null) ? 0 : adve_title.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Adve_table other = (Adve_table) obj;
		if (adve_content == null) {
			if (other.adve_content != null)
				return false;
		} else if (!adve_content.equals(other.adve_content))
			return false;
		if (adve_count == null) {
			if (other.adve_count != null)
				return false;
		} else if (!adve_count.equals(other.adve_count))
			return false;
		if (adve_describe == null) {
			if (other.adve_describe != null)
				return false;
		} else if (!adve_describe.equals(other.adve_describe))
			return false;
		if (adve_id == null) {
			if (other.adve_id != null)
				return false;
		} else if (!adve_id.equals(other.adve_id))
			return false;
		if (adve_image == null) {
			if (other.adve_image != null)
				return false;
		} else if (!adve_image.equals(other.adve_image))
			return false;
		if (adve_time == null) {
			if (other.adve_time != null)
				return false;
		} else if (!adve_time.equals(other.adve_time))
			return false;
		if (adve_title == null) {
			if (other.adve_title != null)
				return false;
		} else if (!adve_title.equals(other.adve_title))
			return false;
		return true;
	}

	public Adve_table(String adve_title, String adve_image, String adve_describe, String adve_content, String adve_time,
			Integer adve_count) {
		super();
		this.adve_title = adve_title;
		this.adve_image = adve_image;
		this.adve_describe = adve_describe;
		this.adve_content = adve_content;
		this.adve_time = adve_time;
		this.adve_count = adve_count;
	}

	public Adve_table() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Adve_table(Integer adve_id, String adve_title, String adve_image, String adve_describe, String adve_content,
			String adve_time, Integer adve_count) {
		super();
		this.adve_id = adve_id;
		this.adve_title = adve_title;
		this.adve_image = adve_image;
		this.adve_describe = adve_describe;
		this.adve_content = adve_content;
		this.adve_time = adve_time;
		this.adve_count = adve_count;
	}

	@Override
	public String toString() {
		return "Adve_table [adve_id=" + adve_id + ", adve_title=" + adve_title + ", adve_image=" + adve_image
				+ ", adve_describe=" + adve_describe + ", adve_content=" + adve_content + ", adve_time=" + adve_time
				+ ", adve_count=" + adve_count + "]\n";
	}


	
	
	
}
