package com.wang.dao;

import java.util.List;

import com.wang.pojo.Address_table;
/**
 * 地址数据表：（address_table）6
 * @author quang
 *
 */
public interface Address_tableDao {
	
	/**
	 *  select
   address_id, address_name, address_content,phone, address_time, username
    from address_table where address_id=#{address_id,jdbcType=INTEGER}
	 * @param address_id
	 * @return
	 */
	public Address_table selectByAddress_table_Id(Integer address_id);
	
	/**
	 * 	根据用户名查总数
	 *  select count(*) from address_table where username= #{username,jdbcType=VARCHAR}
	 * @param address_name
	 * @return
	 */
	public int countByExample(String address_name);
	
	public Address_table selectByAddress_table_UserNAme(String username);
	/**
	 * 根据id和名字删除一个地址
	 *  
    delete from address_table
    where address_id = #{address_id,jdbcType=INTEGER}
	 * @param address_id
	 * @return
	 */
	public int deleteByPrimaryKey(Integer address_id);
	
	/**
	 * 	查询全部
	 *   
    select
    address_id, address_name, address_content,phone, address_time, username
    	from address_table
	 * @return
	 */
	public List<Address_table> selectByAddress_table_ALL();
	/**
	 * 模糊查询
	 *  select 
    address_id, address_name, address_content,phone, address_time, username
    from address_table
    where 
   username like '%' #{username} '%'
	 * @param address_name
	 * @return
	 */
	public List<Address_table> selectByPrimaryKey(String address_name);
	
	
	/**
	 * 	添加一个地址
	 *    insert into address_table ( address_name, address_content,phone, 
      address_time,username
      )
    values ( #{address_name,jdbcType=VARCHAR}, 
    #{address_content,jdbcType=LONGVARCHAR},
    	#{phone,jdbcType=VARCHAR}, 
      #{address_time,jdbcType=VARCHAR}, 
      #{username,jdbcType=VARCHAR}
      )
	 * @param address_table
	 * @return
	 */
	public int insertAdresss_table(Address_table address_table);
	/**
	 * 	添加一个地址
	 *	 动态SQL
	 * @param address_table
	 * @return
	 */
	public int insertSelectiveAddress(Address_table address_table);
	/**
	 * 	修改
	 *   update address_table
    	set address_name = #{address_name,jdbcType=VARCHAR},
      address_content = #{address_content,jdbcType=LONGVARCHAR},
      phone = #{phone,jdbcType=VARCHAR},
      address_time = #{address_time,jdbcType=LONGVARCHAR},
      username= #{username,jdbcType=LONGVARCHAR}
    where address_id = #{address_id,jdbcType=INTEGER}
	 * @param address_table
	 * @return
	 */
	public int updateByPrimars3(Address_table address_table);
	/**
	 * 修改2
	 * @param address_table
	 * @return
	 */
	public int updateByPrimaryKeySelective(Address_table address_table);
	
	/**
	 * 查地址总数
	 *  select count(*) from address_table  
	 * @return
	 */
	public int CountComment();
	
	/**
	 * 批量删除id值
	 * @param id
	 * @return
	 */
	public int DeleteAll_IDS_Chexbox(String []id);
	
}
