package com.wang.pojo;

import java.io.Serializable;
/*
 * 地址数据表：（address_table�?6
 */
public class Address_table implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2182618003563061993L;
		
	private Integer	address_id;	//id
	
	private String	address_name;	//名字
	
	private String	address_content;	//地址内容
	
	private String	phone;		//电话
	
	private String	address_time;	//时间
	
	private String username;

	@Override
	public String toString() {
		return "Address_table [address_id=" + address_id + ", address_name=" + address_name + ", address_content="
				+ address_content + ", phone=" + phone + ", "
						+ "address_time=" + address_time + ", username=" + username
				+ "]\n";
	}

	public Integer getAddress_id() {
		return address_id;
	}

	public void setAddress_id(Integer address_id) {
		this.address_id = address_id;
	}

	public String getAddress_name() {
		return address_name;
	}

	public void setAddress_name(String address_name) {
		this.address_name = address_name;
	}

	public String getAddress_content() {
		return address_content;
	}

	public void setAddress_content(String address_content) {
		this.address_content = address_content;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress_time() {
		return address_time;
	}

	public void setAddress_time(String address_time) {
		this.address_time = address_time;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String usernames) {
		this.username = usernames;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address_content == null) ? 0 : address_content.hashCode());
		result = prime * result + ((address_id == null) ? 0 : address_id.hashCode());
		result = prime * result + ((address_name == null) ? 0 : address_name.hashCode());
		result = prime * result + ((address_time == null) ? 0 : address_time.hashCode());
		result = prime * result + ((phone == null) ? 0 : phone.hashCode());
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address_table other = (Address_table) obj;
		if (address_content == null) {
			if (other.address_content != null)
				return false;
		} else if (!address_content.equals(other.address_content))
			return false;
		if (address_id == null) {
			if (other.address_id != null)
				return false;
		} else if (!address_id.equals(other.address_id))
			return false;
		if (address_name == null) {
			if (other.address_name != null)
				return false;
		} else if (!address_name.equals(other.address_name))
			return false;
		if (address_time == null) {
			if (other.address_time != null)
				return false;
		} else if (!address_time.equals(other.address_time))
			return false;
		if (phone == null) {
			if (other.phone != null)
				return false;
		} else if (!phone.equals(other.phone))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}

	public Address_table( String address_name, String address_content, String phone,
			String address_time, String username) {
		super();
		
		this.address_name = address_name;
		this.address_content = address_content;
		this.phone = phone;
		this.address_time = address_time;
		this.username = username;
	}

	public Address_table() {
		super();
		// TODO Auto-generated constructor stub
	}

		
	
}
