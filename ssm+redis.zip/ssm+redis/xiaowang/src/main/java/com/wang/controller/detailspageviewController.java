/**
 * 
 */
package com.wang.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.Param;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.Comment_table;
import com.wang.pojo.Commodity_table;
import com.wang.pojo.Register_table;
import com.wang.service.Commodity_tableService;
import com.wang.service.util.GetDate;
import com.wang.service.util.ImageSplit;
import com.wang.service.util.RedisTempt_The_Key;
import com.wang.service.Comment_tableService;
/**
 * 根据商品名称去到该商品的信息包括评论信息
 * @author Administrator
 *
 */
@SuppressWarnings("all")
@Controller
public class detailspageviewController {
	@Autowired
	private Commodity_tableService commodity_tableService;
	@Autowired
	private Comment_tableService comment_tableService;
	@Autowired
	private RedisTemplate redisTemplate;
	
	private static final String SUCCESS="SUCCESS";
	private static final String ERROR="ERROR";
	
	private volatile int byid;
	
	
	private volatile String Dname;
	
	//
	private volatile String []striamge;//此数组参数用于当页面传值的时候就赋值给这个数组
	//传商品名称过到
	private volatile String comment_name;
	
	/**
	 * 根据id查询商品信息内部传参
	 * @param id
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("/detailspageview")
	public String detailspageview(@Param("id")Integer id,HttpServletRequest request,
			HttpServletResponse response) throws UnsupportedEncodingException{
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		System.out.println("传进来的标题"+id);
		Commodity_table commodity_table= commodity_tableService.selectComm_atbleKeyById_Service(id);
		//comment_name=commodity_table.getName();
		comment_name=commodity_table.getName();
		System.out.println("根据id查询："+commodity_table);
		
		//将数组参数传进去分割成数组形式，然后用异步读取
		striamge=ImageSplit.getstr(commodity_table.getImage2());
		
		
		byid=id;
		
		
		return "detailspageview";
	}
	/*
	@RequestMapping("/detailspageview")
	public String detailspageviewNameddd(@Param("name")String name){
		System.out.println("传进来的标题"+name);
		Commodity_table commodity_table= commodity_tableService.selectByOrder_tableName_Service(name);
		comment_name=commodity_table.getName();
		System.out.println("根据id查询："+commodity_table);
		
		byid=id;
		return "detailspageview";
	}*/
	/**
	 * 获取图片字段2
	 * 在页面进来就将值赋值给数组
	 * @return
	 */
	@RequestMapping("/getCommentImageList")
	@ResponseBody
	public String[] getimageStrSplit(){
		System.out.println("打印："+this.striamge);
		return this.striamge;
	}
	
	
	
	@RequestMapping("/detailCommName")
	public String detailspageviewName(@Param("name")String name){
		System.out.println("传进来的标题"+name);
		Commodity_table commodity_table= commodity_tableService.selectByOrder_tableName_Service(name);
		System.out.println("根据id查询："+commodity_table);
	
		comment_name=commodity_table.getName();
		Dname=commodity_table.getName();
		
		byid=commodity_table.getId();
		
		return "detailspageview";
	}
	
	/**
	 * 返回商品信息
	 * @return
	 */
	@RequestMapping("/getCommodity_tableID")
	@ResponseBody
	public Commodity_table getCommodity_tableID(){
		System.out.println("内部传值"+byid);
		Commodity_table commodity_table;
		if(byid>0){
			//根据name把商品发送到前端
			commodity_table= commodity_tableService.selectComm_atbleKeyById_Service(byid);
		}else{
			//根据name把商品发送到前端
			commodity_table= commodity_tableService.selectByOrder_tableName_Service(Dname);
		}
		 
		 
		return commodity_table;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * 获取评论数据列表请求
	 * @return
	 */
	@RequestMapping("/getcommentlist")
	@ResponseBody
	public List<Comment_table>getComment_tableList(){
		Comment_table comment_table=new Comment_table();
		comment_table.setName(comment_name);//内部传商品名称
		
		System.out.println("----------输出商品的评论-----------");
		//加个商品名字，
		//防止去到其他的商品的查询的时候查原来的数据
		//redis
		List<Comment_table> comment_tablelist=(List<Comment_table>) redisTemplate.opsForValue().get("comment_tablelist"+comment_name);
		if(comment_tablelist==null){
			comment_tablelist=comment_tableService.selectByComment_table_Service(comment_table);
			redisTemplate.opsForValue().set("comment_tablelist"+comment_name, comment_tablelist);//添加到缓存中
		}
		 System.out.println(comment_tablelist);
		return comment_tablelist;
	}
	/**‘
	 * 5555565656io656564
	 * 	 * 评论点赞请求
	 * @param cid
	 * @return
	 */
	 
	@RequestMapping("/getpraiseyes")
	@ResponseBody
	public Object togetPraise(@Param("cid")Integer cid,HttpSession session){
		redisTemplate.delete("comment_tablelist"+comment_name);
		//删除缓存的key
		System.out.println("cid="+cid);
		Register_table register_table=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		 //放进reids
		 if(register_table==null){ //先判断有没有登录
			 //返回ERROR
			 return ERROR;
		 }
		Comment_table comment_table=new Comment_table();
		comment_table.setCid(cid);
		comment_table.setPraise(1);
		int index=comment_tableService.updatePraiseComment_table_Service(comment_table);
		if(index>0){
			return SUCCESS;
		}else{
			return ERROR;
		}
		 
	}
	
	/**
	 * 评论请求
	 * @param content
	 * @param session
	 * @return
	 */
	@RequestMapping("/sendMessageCommentContent")
	@ResponseBody
	public Object sendContentMessage(@Param("content")String content,HttpSession session){
		 
		Register_table register_table=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		 //放进reids
		 if(register_table==null){ //先判断有没有登录
			 //返回ERROR
			 return ERROR;
		 }
		 int praise=0;//默认设置点赞值为零
		String username= register_table.getUsername();
		String date=GetDate.getdate();//获取时间格式
		Comment_table comment_table=new Comment_table(comment_name, content, praise, username, date);
		//将参数注入构造器
		int index=comment_tableService.insertComment_table_Service(comment_table);
		if(index>0){
			redisTemplate.delete("comment_tablelist"+comment_name);
			//删除缓存的key
			//提交成功返回SUCCESS
			return SUCCESS;
		}else{
			//提交失败的信息
			return "ERRORMESSAGE";
		}
	 
	}
	
 
}
