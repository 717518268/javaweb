package com.wang.dao;

import java.util.List;

import com.wang.pojo.Weixin_table;

public interface Weixin_tableDao {
	
	public int  insertOpendids(Weixin_table weixin_table);
	
	public Weixin_table selectGetNameOpenidCount(String openid);
	
	public List<Weixin_table>selectALLOpenid();
	
	public int deleteopenid(int id);
	
	public int countByExample();
	
	public Weixin_table updateByPrimaryKey(Weixin_table weixin_table);
}
