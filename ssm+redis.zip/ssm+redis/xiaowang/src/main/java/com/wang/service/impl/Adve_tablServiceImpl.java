package com.wang.service.impl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wang.dao.Adve_tableDao;
import com.wang.pojo.Adve_table;
import com.wang.service.Adve_tableService;

@Service
@Transactional
public class Adve_tablServiceImpl implements Adve_tableService {
	@Autowired
	private Adve_tableDao adve_tableDao;
	/**
	 * 查所�?
	 * @return
	 */
	public List<Adve_table> selectAdve_atbleAllService() {
		
		return adve_tableDao.selectAdve_atbleAll();
	}
	/**
	 * 根据id查询
	 * @param adve_id
	 * @return
	 */
	public Adve_table selectadve_tableByIdService(Integer adve_id) {
		
		return adve_tableDao.selectadve_tableById(adve_id);
	}
	/**
	 * 查�?�数
	 * @return
	 */
	public Integer countadve_tabkleService() {
		// TODO Auto-generated method stub
		return adve_tableDao.countadve_tabkle();
	}
	/**
	 * 插入�?条广�?
	 * @param adve_table
	 * @return
	 */
	public int insertAdve_tableService(Adve_table adve_table) {
		// TODO Auto-generated method stub
		return adve_tableDao.insertAdve_table(adve_table);
	}
	/**
	 * 根据id修改
	 * @param adve_id
	 * @return
	 */
	public int updatesAdve_TableIdService(Adve_table adve_table) {
		// TODO Auto-generated method stub
		return adve_tableDao.updatesAdve_TableId(adve_table);
	}
	/**
	 * 根据id修改SQL
	 * @param adve_id
	 * @return
	 */
	public int  updateBYIdSQLService(Adve_table adve_table) {
		// TODO Auto-generated method stub
		return adve_tableDao.updateBYIdSQL(adve_table);
	}
	/**
	 * 根据id删除
	 * @param adve_id
	 * @return
	 */
	public int deleteAdve_tablrBYIDService(Integer adve_id) {
		// TODO Auto-generated method stub
		return adve_tableDao.deleteAdve_tablrBYID(adve_id);
	}
	/**
	 * 删除 
	 * @param adve_id
	 * @return
	 */
	public int deleteAdVeBKeyService(Integer adve_id) {
		// TODO Auto-generated method stub
		return adve_tableDao.deleteAdVeBKey(adve_id);
	}
	
	/**
	 * 批量删除啊
	 */
	public int DeleteAll_IDS_Chexbox_Adve_table(String adve_id) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		String []ids=adve_id.split(",");//进行逗号字符分割
	 
		int indexValue=adve_tableDao.DeleteAll_IDS_Chexbox_Adve_table(ids);
		//调用服务层
		
		return  indexValue;
	}

}
