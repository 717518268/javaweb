package com.wang.pojo;

import java.io.Serializable;

import java.util.List;
/**
 * 注册表：（和微信账号）（register_table�?	6个字�?
 * @author �?
 *
 */
public class Register_table implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -634281497625277345L;
	
	private Integer id;
	public Register_table(Integer id, String nickname, String sex, String headimage) {
		super();
		this.id = id;
		this.nickname = nickname;
		this.sex = sex;
		this.headimage = headimage;
	}

	//id自增
	private String nickname;
	//昵称
	private String  username;
	//账号
	private String password;
	//密码
	private String sex;
	//性别
	private String time;
	//时间
	private String headimage;
	//头像图片路径
	
	private List<Cart_table> cart_table;
	/*
	 * 对应购物车表
	 * 7个字�?
	 */
	private List<Address_table> address_table;
	/*
	 * 对应地址�?
	 * 6个字�?
	 */
	private List<Order_table> order_table;
	/*
	 * 对应订单�?
	 * 9个字�?
	 */
	
		
	
	public List<Cart_table> getCart_table() {
		return cart_table;
	}

	public void setCart_table(List<Cart_table> cart_table) {
		this.cart_table = cart_table;
	}

	public List<Address_table> getAddress_table() {
		return address_table;
	}

	public void setAddress_table(List<Address_table> address_table) {
		this.address_table = address_table;
	}

	public List<Order_table> getOrder_table() {
		return order_table;
	}

	public void setOrder_table(List<Order_table> order_table) {
		this.order_table = order_table;
	}

	public Register_table() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address_table == null) ? 0 : address_table.hashCode());
		result = prime * result + ((cart_table == null) ? 0 : cart_table.hashCode());
		result = prime * result + ((headimage == null) ? 0 : headimage.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((nickname == null) ? 0 : nickname.hashCode());
		result = prime * result + ((order_table == null) ? 0 : order_table.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((sex == null) ? 0 : sex.hashCode());
		result = prime * result + ((time == null) ? 0 : time.hashCode());
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}





	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Register_table other = (Register_table) obj;
		if (address_table == null) {
			if (other.address_table != null)
				return false;
		} else if (!address_table.equals(other.address_table))
			return false;
		if (cart_table == null) {
			if (other.cart_table != null)
				return false;
		} else if (!cart_table.equals(other.cart_table))
			return false;
		if (headimage == null) {
			if (other.headimage != null)
				return false;
		} else if (!headimage.equals(other.headimage))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (nickname == null) {
			if (other.nickname != null)
				return false;
		} else if (!nickname.equals(other.nickname))
			return false;
		if (order_table == null) {
			if (other.order_table != null)
				return false;
		} else if (!order_table.equals(other.order_table))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (sex == null) {
			if (other.sex != null)
				return false;
		} else if (!sex.equals(other.sex))
			return false;
		if (time == null) {
			if (other.time != null)
				return false;
		} else if (!time.equals(other.time))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}





	public String getNickname() {
		return nickname;
	}





	public void setNickname(String nickname) {
		this.nickname = nickname;
	}





	public String getUsername() {
		return username;
	}





	public void setUsername(String username) {
		this.username = username;
	}





	public String getPassword() {
		return password;
	}





	public void setPassword(String password) {
		this.password = password;
	}





	public String getSex() {
		return sex;
	}





	public void setSex(String sex) {
		this.sex = sex;
	}





	public String getTime() {
		return time;
	}





	public void setTime(String time) {
		this.time = time;
	}





	public String getHeadimage() {
		return headimage;
	}





	public void setHeadimage(String headimage) {
		this.headimage = headimage;
	}

	@Override
	public String toString() {
		return "Register_table [id=" + id + ", nickname=" + nickname + ", username=" + username + ", password="
				+ password + ", sex=" + sex + ", time=" + time + ", headimage=" + headimage + ",\n cart_table="
				+ cart_table + ",\n address_table=" + address_table + ",\n order_table=" + order_table + "]";
	}




	
	
	
	
}
