package com.wang.service;

import java.util.List;

import com.wang.pojo.CallMeTable;

public interface CallMeTableService {
	/**
	 * 用户联系或者反馈的数据
	 * 返回一个列表
	 * @return
	 */
	public List<CallMeTable>selectByCallMEAllList();
	/**
	 * 批量删除id
	 * 评论我的
	 * @param id
	 * @return
	 */
	public int deleteByCallMETableIdIDS(String id);
	/**
	 * 根据id查询一个用户反馈的信息
	 * @param id
	 * @return
	 */
	public CallMeTable selectByCallMETable(Integer  id);
	
	
	
	public Integer insertCallMETable(CallMeTable CallMeTable);
	/**
	 * 插入一条信息
	 * @param CallMeTable
	 * @return
	 */
	public Integer insertCallMETableSQL(CallMeTable CallMeTable);
	/**
	 * 查总数
	 * @return
	 */
	public Integer countByCallMETable();
	/**
	 * 根据id删除
	 * @param id
	 * @return
	 */
	public Integer deleteByCallMETableId(Integer id);
	
	
	public Integer updateCallMETable(CallMeTable callMeTable);
	
}
