package com.wang.pojo;

import java.io.Serializable;
import java.util.List;
/**
 * 
商品数据表（commodity_table�?	12个字�?
 * @author �?
 *
 */
public class Commodity_table implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5919140392216600507L;
	
				
			private Integer	id;	//id
			
			private String	title;	//标题
			
			private String 	name;	//商品名字
			
			private int	count; 	//数量
			
			private Double	price;	//价格
			
			private String	image1;	//描述图片
			
			private String	image2;	//	描述图片

			
			
			private String	origin;		//（省）发货地
			
			private String	details;		//详情
			
			private String	time;		//时间
			
			private List<Comment_table>comment_table;
			
			public List<Comment_table> getComment_table() {
				return comment_table;
			}

			public void setComment_table(List<Comment_table> comment_table) {
				this.comment_table = comment_table;
			}

			private Integer commoditycount;
			public String getImage2() {
				return image2;
			}

			public void setImage2(String image2) {
				this.image2 = image2;
			}
			@Override
			public int hashCode() {
				final int prime = 31;
				int result = 1;
				result = prime * result + ((commoditycount == null) ? 0 : commoditycount.hashCode());
				result = prime * result + count;
				result = prime * result + ((details == null) ? 0 : details.hashCode());
				result = prime * result + ((image2 == null) ? 0 : image2.hashCode());
				result = prime * result + ((id == null) ? 0 : id.hashCode());
				result = prime * result + ((image1 == null) ? 0 : image1.hashCode());
			 
				result = prime * result + ((name == null) ? 0 : name.hashCode());
				result = prime * result + ((origin == null) ? 0 : origin.hashCode());
				result = prime * result + ((price == null) ? 0 : price.hashCode());
				result = prime * result + ((time == null) ? 0 : time.hashCode());
				result = prime * result + ((title == null) ? 0 : title.hashCode());
				return result;
			}

			@Override
			public boolean equals(Object obj) {
				if (this == obj)
					return true;
				if (obj == null)
					return false;
				if (getClass() != obj.getClass())
					return false;
				Commodity_table other = (Commodity_table) obj;
				if (commoditycount == null) {
					if (other.commoditycount != null)
						return false;
				} else if (!commoditycount.equals(other.commoditycount))
					return false;
				if (count != other.count)
					return false;
				if (details == null) {
					if (other.details != null)
						return false;
				} else if (!details.equals(other.details))
					return false;
				if (image2 == null) {
					if (other.image2 != null)
						return false;
				} else if (!image2.equals(other.image2))
					return false;
				if (id == null) {
					if (other.id != null)
						return false;
				} else if (!id.equals(other.id))
					return false;
				if (image1 == null) {
					if (other.image1 != null)
						return false;
				} else if (!image1.equals(other.image1))
					return false;
				 
				 
				if (name == null) {
					if (other.name != null)
						return false;
				} else if (!name.equals(other.name))
					return false;
				if (origin == null) {
					if (other.origin != null)
						return false;
				} else if (!origin.equals(other.origin))
					return false;
				if (price == null) {
					if (other.price != null)
						return false;
				} else if (!price.equals(other.price))
					return false;
				if (time == null) {
					if (other.time != null)
						return false;
				} else if (!time.equals(other.time))
					return false;
				if (title == null) {
					if (other.title != null)
						return false;
				} else if (!title.equals(other.title))
					return false;
				return true;
			}

			@Override
			public String toString() {
				return "Commodity_table [id=" + id + ", title=" + title + ", name=" + name + ", count=" + count
						+ ", price=" + price + ", image1=" + image1 + ", image2=" + image2 
						+ " origin=" + origin + ", details=" + details + ", time=" + time
						+ ", commodity_count=" + commoditycount + "]";
			}

			public Commodity_table(String title, String name, int count, Double price, String image1, String image2,
					  String origin, String details, String time, Integer commoditycount) {
				super();
				this.title = title;
				this.name = name;
				this.count = count;
				this.price = price;
				this.image1 = image1;
				this.image2 = image2;
				 
			 
				this.origin = origin;
				this.details = details;
				this.time = time;
				this.commoditycount = commoditycount;
			}

			public Integer getId() {
				return id;
			}

			public void setId(Integer id) {
				this.id = id;
			}

			public String getTitle() {
				return title;
			}

			public void setTitle(String title) {
				this.title = title;
			}

			public String getName() {
				return name;
			}

			public void setName(String name) {
				this.name = name;
			}

			public int getCount() {
				return count;
			}

			public void setCount(int count) {
				this.count = count;
			}

			public Double getPrice() {
				return price;
			}

			public void setPrice(Double price) {
				this.price = price;
			}

			public String getImage1() {
				return image1;
			}

			public void setImage1(String image1) {
				this.image1 = image1;
			}

		 

		

			public String getOrigin() {
				return origin;
			}

			public void setOrigin(String origin) {
				this.origin = origin;
			}

			public String getDetails() {
				return details;
			}

			public void setDetails(String details) {
				this.details = details;
			}

			public String getTime() {
				return time;
			}

			public void setTime(String time) {
				this.time = time;
			}

			public Integer getCommodity_count() {
				return commoditycount;
			}

			public void setCommodity_count(Integer commoditycount) {
				this.commoditycount = commoditycount;
			}

			public static long getSerialversionuid() {
				return serialVersionUID;
			}

			public Commodity_table() {
				super();
				// TODO Auto-generated constructor stub
			}
	
				
	
	
	
	
}
