package com.wang.controller;

import java.util.ArrayList;
import java.util.List;


import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.Cart_table;
import com.wang.pojo.Register_table;
import com.wang.service.Cart_tableService;
import com.wang.service.util.RedisTempt_The_Key;

@Controller
public class CartViewController {
	
	
	 
	/**
	 * 依赖注入
	 */
	@Autowired
	private Cart_tableService cart_tableService;
	@SuppressWarnings("all")
	@Autowired
	private RedisTemplate redisTemplate;
	/**
	 * 购物车请求控制器
	 * @param model
	 * @return
	 */
	@RequestMapping("/cartview")
	public String cartview(Model model,HttpSession session){
	 
		//先判断是否已经登录，如果等于null就重定向到登录页
		Register_table register_table=(Register_table)redisTemplate.opsForValue().get(RedisTempt_The_Key.USER);
		if(register_table==null){
			return "redirect:login";
		}
		String username=register_table.getUsername();
		List<Cart_table>list=cart_tableService.findeNameCart_table_Service(username);
		model.addAttribute("cart", list);
		return "cartview";
	}
	 
	
	@RequestMapping("/cartTableList")
	@ResponseBody
	public List<Cart_table> cart_TAbleALe(HttpSession session){
		/**
		 * 去登录会话里找
		 */
		Register_table register_table=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		String username=register_table.getUsername();
		//根据username查找购物车的信息
		List<Cart_table>list=cart_tableService.findeNameCart_table_Service(username);
		return  list;
	}
	
	/**
	 * 删除购物车商品
	 * @param id
	 * @return
	 */
	@RequestMapping("/carDeleteById")
	@ResponseBody
	public Object carDeleteById(@Param("index")Integer index){
		int id=cart_tableService.deleteByCart_tableId_Service(index);
		if(id>0){//删除成功就返回SUCCESS
			return "SUCCESS";
		}
		return "ERROE";
	}
	
	/***
	 * /批量删除自己的购物车
	 * @param id
	 * @return
	 */
	@RequestMapping("/deleteMySelfCart")
	@ResponseBody
	public String deleteMySelfCart(@Param("id")String id){
		
		
		int value=cart_tableService.deleteByCart_tableIDS(id);
		if(value>0){
			//进行控制
		}
		return "ok";
	}
	
	
	
	
}
