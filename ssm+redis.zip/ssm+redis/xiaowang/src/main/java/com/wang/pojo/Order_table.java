package com.wang.pojo;

import java.io.Serializable;
/*
 * 

订单表（order_table�?		9个字�?
 * 
 */
public class Order_table implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5616180331009489294L;
	
	private Integer id;
	
	private String order_number;	//订单�?

	private String comm_name;	//商品名字

	private String image1;//图片
	
    private Integer	count;		//数量

	private Double price;		//价格

	private String state;		//支付状�??

	private String username;	//用户�?

	 

	private String address;		//地址
	
	 

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOrder_number() {
		return order_number;
	}

	public void setOrder_number(String order_number) {
		this.order_number = order_number;
	}

	public String getComm_name() {
		return comm_name;
	}

	public void setComm_name(String comm_name) {
		this.comm_name = comm_name;
	}

	public String getImage1() {
		return image1;
	}

	public void setImage1(String image1) {
		this.image1 = image1;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

 

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	 
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		
		result = prime * result + ((comm_name == null) ? 0 : comm_name.hashCode());
		result = prime * result + ((count == null) ? 0 : count.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((image1 == null) ? 0 : image1.hashCode());
		result = prime * result + ((order_number == null) ? 0 : order_number.hashCode());
		
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order_table other = (Order_table) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		 
		if (comm_name == null) {
			if (other.comm_name != null)
				return false;
		} else if (!comm_name.equals(other.comm_name))
			return false;
		if (count == null) {
			if (other.count != null)
				return false;
		} else if (!count.equals(other.count))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (image1 == null) {
			if (other.image1 != null)
				return false;
		} else if (!image1.equals(other.image1))
			return false;
		if (order_number == null) {
			if (other.order_number != null)
				return false;
		} else if (!order_number.equals(other.order_number))
			return false;
		 
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Order_table [id=" + id + ", order_number=" + order_number + ", comm_name=" + comm_name + ", image1="
				+ image1 + ", count=" + count + ", price=" + price + ", state=" + state + ", username=" + username
				+ ", address=" + address + ",]";
	}

	public Order_table(
			String order_number, String comm_name, 
			String image1, Integer count,
			double price2, String state,
			String username, String address) {
		super();
		this.order_number = order_number;
		this.comm_name = comm_name;
		this.image1 = image1;
		this.count = count;
		this.price = price2;
		this.state = state;
		this.username = username;
		 
		this.address = address;
	 
	}

	public Order_table() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
}
