package com.wang.dao;

import java.util.List;

import com.wang.pojo.Commodity_table;
/**
 * 商品数据表（commodity_table）	12个字段
 * @author quang
 *	id  自增
 *	time 自动生成
 */
public interface Commodity_tableDao {
	/**
	 * 根据商品名字查询对象
	 * @param name
	 * @return
	 */
	public Commodity_table selectComm_atbleKeyByName(String name);
	
	/**
	 * 模糊查询进行商品分类
	 * @param title
	 * @return
	 */
	public List<Commodity_table>selectListComm_tableTitle(String title);
	
	/**
	 * 查所有
	 * @return
	 */
	public List<Commodity_table>selectListComm_table();
	
	/**
	 * 查询所有分类
	 * @return
	 */
	public List<String>selectListComm_tableName();
	
	/**
	 *	 根据id查询一个商品
	 * @param id
	 * @return
	 */
	public Commodity_table selectComm_atbleKeyById(Integer id);
 
	/**
	 * 添加商品
	 * @param commodity_table
	 * @return
	 */
	public int insertCommont_table(Commodity_table commodity_table);
	
	/**
	 * 添加商品
	 * @param commodity_table
	 * @return
	 */
	public int insertSelectiveComm_table(Commodity_table commodity_table);
	
	/**
	 * 	查库存放进redis里
	 * @param id
	 * @return
	 */
	public int countByExample(Integer id);
	
	/**
	 * 查总数
	 * @return
	 */
	public int CountAllComment();
	/**
    动态SQL
* @param commodity_table
* @return
*/
	public int updateBySQlSelective(Commodity_table commodity_table);
	/**
	 * 	除了时间不用改和id
	 * @param commodity_table
	 * @return
	 */
	public int updateComm_tableKeyAll(Commodity_table commodity_table);
	
	/**
	 *	 库存减少
	 * @param commodity_table
	 * @return
	 */
	public int updateByPrimaryKeyId(Commodity_table commodity_table);
	/**
	 * 	根据id删除一个商品
	 * @param id
	 * @return
	 */
	public int deleteByPrimaryKeyID(Integer id);
	
	/**
	 * 批量删除
	 *    <!-- 
    批量删除 
    -->
  <delete id="deleteCommodity_tableIds" parameterType="java.lang.String">
    delete from commodity_table where id in
  <foreach item="id" collection="array" index="no" open="(" separator="," close=")">
  #{id}
  </foreach>
  </delete>
  
	 * @return
	 */
	public int deleteCommodity_tableIds(String []id);
	
	/**
	 * 访问量写进
	 * @param commodity_table
	 * @return
	 */
	public int updateCommCountKeyId(Commodity_table commodity_table);
	/**
	 * 根据商品名字库存减少
	 * @param Commodity_table
	 * @return
	 */
	public  int updateByPrimaryKeyNameCountAuto(Commodity_table Commodity_table);
}
