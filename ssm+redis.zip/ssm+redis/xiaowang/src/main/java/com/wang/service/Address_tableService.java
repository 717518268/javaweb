package com.wang.service;

import java.util.List;



import com.wang.pojo.Address_table;

public interface Address_tableService {
	/**
	 * 	根据用户名查总数
	 * @param address_name
	 * @return
	 */
	public int countByExample_Service(String address_name);
	
	/**
	 * 查地址总数
	 * @return
	 */
	public int CountComment();
	/**
	 * 根据username查地址
	 * @param id
	 * @return
	 */
	public Address_table selectByAddress_table_UserNAme(String username);
	/**
	 * 根据id查地址
	 * @param id
	 * @return
	 */
	public Address_table selectByAddress_table_Id_Service(Integer id);
	
	/**
	 * 根据id和名字删除一个地�??
	 * @param address_id
	 * @return
	 */
	public int deleteByPrimaryKey_Service(Integer address_id);
	
	/**
	 * 	查询全部
	 * @return
	 */
	public List<Address_table> selectByAddress_table_ALL_Service();
	
	/**
	 * 模糊查询
	 * @param address_name
	 * @return
	 */
	public List<Address_table> selectByPrimaryKey_Service(String address_name);
	
	
	/**
	 * 	添加�??个地�??
	 * @param address_table
	 * @return
	 */
	public int insertAdresss_table_Service(Address_table address_table);
	/**
	 * 	添加�??个地�??
	 *	 动�?�SQL
	 * @param address_table
	 * @return
	 */
	public int insertSelectiveAddress_Service(Address_table address_table);
	/**
	 * 	修改
	 * @param address_table
	 * @return
	 */
	public int updateByPrimars3_Service(Address_table address_table);
	/**
	 * 修改2
	 * @param address_table
	 * @return
	 */
	public int updateByPrimaryKeySelective_Service(Address_table address_table);
	
	/**
	 * 批量删除id值
	 * @param id
	 * @return
	 */
	public int DeleteAll_IDS_Chexbox(String []id);
	
}
