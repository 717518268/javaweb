package com.wang.service;

import java.util.List;

import com.wang.pojo.Comment_table;

public interface Comment_tableService {
	/**
	 * 查询所有的评论信息
	 * @return
	 */
	public List<Comment_table>selectByComment_table_Service(Comment_table comment_table);
	
	/**
	 * 查询自己所有的评论信息
	 * @return
	 */
	public List<Comment_table>selectBymyselListComment_table(Comment_table comment_table);
	/**
	 * 根据id查询评论信息
	 * @param cid
	 * @return
	 */
	public Comment_table selectByComment_tableID_Service(Integer cid);
	/**
	 * 删除一条
	 * @param cid
	 * @return
	 */
	public int deleteByComment_table_Service(Integer cid);
	/**
	 * 添加一条评论
	 * @param comment_table
	 * @return
	 */
	public int insertComment_table_Service(Comment_table comment_table);
	/***
	 * 动态sQL插入评论
	 * @param comment_table
	 * @return
	 */
	public int insertSQLComment_table_Service(Comment_table comment_table);
	/**
	 * 根据商品查询评论信息
	 * @param name
	 * @return
	 */
	public Integer Comment_tablecount_Service(String name);
	/**
	 * 批量删除评论的数据
	 * @param cid
	 * @return
	 */
	public int deleteComment_tableIds(String cid);
	/**
	 * 点赞修改
	 * 只需要注入一个参数praise
	 * @param comment_table
	 * @return
	 */
	public Integer updatePraiseComment_table_Service(Comment_table comment_table);
}
