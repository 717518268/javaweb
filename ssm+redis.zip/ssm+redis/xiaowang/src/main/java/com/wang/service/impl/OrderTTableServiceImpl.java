package com.wang.service.impl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wang.dao.OrderTableDao;
import com.wang.pojo.Order_table;
import com.wang.service.Order_tableService;

@Service
@Transactional
public class OrderTTableServiceImpl implements Order_tableService{
	
	@Autowired
	private OrderTableDao orderTableDao;
	/**
	 * 模糊查询
	 */
	public List<Order_table> selectByNameOrder_table_Service(String username) {
		
		return orderTableDao.selectByNameOrder_table(username);
	}
	/**
	 * 根据id查询�?个对�?
	 */
	public Order_table selectByOrder_tableId_Service(Integer id) {
		
		return orderTableDao.selectByOrder_tableId(id);
	}
	/**
	 * 查询�?�?
	 */
	public List<Order_table> selectAllOrder_table_Service() {
		
		return orderTableDao.selectAllOrder_table();
	}
	
	/**
	 * 删除
	 */
	public int deleteByOrder_table_Service(Integer id) {
		
		return orderTableDao.deleteByOrder_table(id);
	}
	/**
	 * 插入
	 */
	public int insertOrder_table_Service(Order_table order_table) {
		// TODO Auto-generated method stub
		return orderTableDao.insertOrder_table(order_table);
	}
	/**
	 * 插入
	 */
	public int insertOrder_table2_Service(Order_table order_table) {
		// TODO Auto-generated method stub
		return orderTableDao.insertOrder_table2(order_table);
	}
	/**
	 * 查�?�数
	 */
	public int countOrder_table_Service() {
		// TODO Auto-generated method stub
		return orderTableDao.countOrder_table()
				;
	}
	
	/**
	 * 根据名字查询总数
	 */
	public int countOrder_table_ByName_Service(String username) {
		// TODO Auto-generated method stub
		return orderTableDao.countOrder_table_ByName(username);
	}
	
	/**
	 * 更改
	 */
	public int updateOrder_table_Service(Order_table order_table) {
		// TODO Auto-generated method stub
		return orderTableDao.updateOrder_table(order_table);
	}
	public int updateOrder_table_buNumber_Service(Order_table order_table) {
		// TODO Auto-generated method stub
		return orderTableDao.updateOrder_table_buNumber(order_table);
	}
	
	/**
	 * 批量删除订单服务层
	 */
	public int delete_ByOrder_tableAll_Ids(String id) {
		
		String []ids=id.split(",");
		// TODO Auto-generated method stub
		int value=orderTableDao.delete_ByOrder_tableAll_Ids(ids);
		return  value;
	}

}
