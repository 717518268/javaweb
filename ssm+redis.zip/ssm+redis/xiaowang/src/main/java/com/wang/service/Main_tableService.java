package com.wang.service;

import java.util.List;



import com.wang.pojo.Main_table;

public interface Main_tableService {
	/**
	 * 增加访问量
	 * @param main_table
	 * @return
	 */
	public int updateByCountAccess(Main_table main_table);
	/**
	 *	 普�?�插�??
	 * @param main_table
	 * @return
	 */
	public int insertMain_tabledaoService(Main_table main_table);
	/**
	 * 	插入
	 * SQL防注�??
	 * @param main_table
	 * @return
	 */
	public int insertMain_tableSelectiveService(Main_table main_table);
	/**
	 * 查一组集�??
	 * @return
	 */
	public List<Main_table>selectByMain_tableService();
	
	/**
	 * 	根据id查一个对�??
	 * @param id
	 * @return
	 */
	public Main_table selectByMain_tableKeyService(Integer id);
	
	
	/**
	 * 	查�?�数
	 * @return
	 */
	public int selectcountByMain_tableService();
	
	
	
	/**=========修改===================*/
	
	
	/**
	 *	 更改5个字�??
	 *	动�?�SQL
	 * @param main_table
	 * @return
	 */
	public int updateByKeySelective5Service(Main_table main_table);
	
	/**
	 *	 更改5个字�??
	 * @param main_table
	 * @return
	 */
	public int UpdateMain_table5(Main_table main_table);
	/**
	 *	 更改3个字�??
	 * @param main_table
	 * @return
	 */
	public int updateByPrimaryKey3Service(Main_table main_table);
	
	/**=-==============删除========================**/
	/**
	 * 根据id删除�??�??
	 * @param main_id
	 * @return
	 */
	public int deleteByPrimaryKeyIDService(Integer main_id);
	
	
	
}
