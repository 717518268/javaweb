package com.wang.dao;

import java.util.List;

import com.wang.pojo.Main_table;
/**
 * 
主页的数据表参数	（main_table）	浏览数据（设置物品分类）
 * @author 铨
 *
 */
public interface Main_tableDao {
	/**
	 *	 普通插入
	 * @param main_table
	 * @return
	 */
	public int insertMain_tabledao(Main_table main_table);
	/**
	 * 	插入
	 * SQL防注入
	 * @param main_table
	 * @return
	 */
	public int insertMain_tableSelective(Main_table main_table);
	/**
	 * 查一组集合
	 * @return
	 */
	public List<Main_table>selectByMain_table();
	
	/**
	 * 	根据id查一个对象
	 * @param id
	 * @return
	 */
	public Main_table selectByMain_tableKey(Integer id);
	
	

	/**
	 * 	查总数
	 * @return
	 */
	public int selectcountByMain_table();
	
	
	
/**=========修改===================*/
	
	
	/**
	 *	 更改5个字段
	 *	动态SQL
	 * @param main_table
	 * @return
	 */
	public int updateByKeySelective5(Main_table main_table);
	
	/**
	 *	 更改5个字段
	 * @param main_table
	 * @return
	 */
	public int UpdateMain_table5(Main_table main_table);
	/**
	 *	 更改3个字段
	 * @param main_table
	 * @return
	 */
	public int updateByPrimaryKey3(Main_table main_table);
	
	/**=-==============删除========================**/
	/**
	 * 根据id删除一个
	 * @param main_id
	 * @return
	 */
	public int deleteByPrimaryKeyID(Integer main_id);
	
	/**
	 * 增加访问量
	 * @param main_table
	 * @return
	 */
	public int updateByCountAccess(Main_table main_table);
	
}
