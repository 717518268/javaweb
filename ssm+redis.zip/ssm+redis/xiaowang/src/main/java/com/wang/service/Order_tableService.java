package com.wang.service;

import java.util.List;



import com.wang.pojo.Order_table;
/**
 * 订单服务层
 * @author Administrator
 *
 */
public interface Order_tableService {
	/**
	 * 订单模糊查询
	 * @return
	 */
	public List<Order_table>selectByNameOrder_table_Service(String username);
	
	/**
	 * 服务层根据id批量删除
	 * @param id
	 * @return
	 */
	public int delete_ByOrder_tableAll_Ids(String id);
	/**
	 * 根据id查询
	 * @param id
	 * @return
	 */
	public Order_table selectByOrder_tableId_Service(Integer id);
	
	/**
	 * 查所�??
	 * @return
	 */
	public List<Order_table>selectAllOrder_table_Service();
	
	/**
	 * 删除
	 * @param id
	 * @return
	 */
	public int deleteByOrder_table_Service(Integer id);
	
	/**
	 * 添加�??个订�??
	 * @param order_table
	 * @return
	 */
	public int insertOrder_table_Service(Order_table order_table);
	/**
	 * 添加�??个订�??
	 * @param order_table
	 * @return
	 */
	public int insertOrder_table2_Service(Order_table order_table);
	
	/**
	 * 订单总数
	 * @return
	 */
	public int countOrder_table_Service();
	
	/**
	 * 查个人订单的总数
	 * @return
	 */
	public int countOrder_table_ByName_Service(String username);
	/**
	 * 修改状�??
	 * set�??个state
	 * @param order_table
	 * @return
	 */
	public int updateOrder_table_Service(Order_table order_table);
	/**
	 * 
	 * @param order_table
	 * @return
	 */
	public int updateOrder_table_buNumber_Service(Order_table order_table);	
}
