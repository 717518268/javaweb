package com.wang.service.util;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ��ȡʱ����
 * @author Administrator
 *
 */
public class GetDate {
	
	/**
	 * 获取时间
	 * @return
	 */
	public static String getdate(){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String sd=sdf.format(new Date());
		return sd;
	}
	
	/**
	 * 匹配数字
	 * @return
	 */
	public static String getNumberData(){
		
		String nowdatda=getdate();


		String regEx="[^0-9]";
		
		Pattern per=Pattern.compile(regEx);
		Matcher match=per.matcher(nowdatda);
		String index=match.replaceAll("").trim();
		return index;
	}
	
}
