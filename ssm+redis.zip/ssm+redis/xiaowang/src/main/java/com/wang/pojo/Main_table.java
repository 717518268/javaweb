package com.wang.pojo;

import java.io.Serializable;
/**
 * 主页的数据表参数	（main_table�?
 * 展示页面的图片数�?
 * 不包括轮播图
 * @author �?
 *
 */
public class Main_table implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8203647167429960014L;
	
	private Integer main_id;
	//主id
	private String main_title;
	//标题
	private String main_content;
	//内容
	private Integer main_access;
	//访问量记�?
	private String main_image;
	//图片
	private String main_time;
	//时间
	
	
	
	@Override
	public String toString() {
		return "Main_table [main_id=" + main_id + ", main_title=" + main_title + ", main_content=" + main_content
				+ ", main_access=" + main_access + ", main_image=" + main_image + ", main_time=" + main_time + "]\n";
	}
	public Main_table(String main_title, String main_content, Integer main_access, String main_image,
			String main_time) {
		super();
		this.main_title = main_title;
		this.main_content = main_content;
		this.main_access = main_access;
		this.main_image = main_image;
		this.main_time = main_time;
	}
	public Main_table() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * get/set
	 * @return
	 */
	public Integer getMain_id() {
		return main_id;
	}
	public void setMain_id(Integer main_id) {
		this.main_id = main_id;
	}
	public String getMain_title() {
		return main_title;
	}
	public void setMain_title(String main_title) {
		this.main_title = main_title;
	}
	public String getMain_content() {
		return main_content;
	}
	public void setMain_content(String main_content) {
		this.main_content = main_content;
	}
	public Integer getMain_access() {
		return main_access;
	}
	public void setMain_access(Integer main_access) {
		this.main_access = main_access;
	}
	public String getMain_image() {
		return main_image;
	}
	public void setMain_image(String main_image) {
		this.main_image = main_image;
	}
	public String getMain_time() {
		return main_time;
	}
	public void setMain_time(String main_time) {
		this.main_time = main_time;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((main_access == null) ? 0 : main_access.hashCode());
		result = prime * result + ((main_content == null) ? 0 : main_content.hashCode());
		result = prime * result + ((main_id == null) ? 0 : main_id.hashCode());
		result = prime * result + ((main_image == null) ? 0 : main_image.hashCode());
		result = prime * result + ((main_time == null) ? 0 : main_time.hashCode());
		result = prime * result + ((main_title == null) ? 0 : main_title.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Main_table other = (Main_table) obj;
		if (main_access == null) {
			if (other.main_access != null)
				return false;
		} else if (!main_access.equals(other.main_access))
			return false;
		if (main_content == null) {
			if (other.main_content != null)
				return false;
		} else if (!main_content.equals(other.main_content))
			return false;
		if (main_id == null) {
			if (other.main_id != null)
				return false;
		} else if (!main_id.equals(other.main_id))
			return false;
		if (main_image == null) {
			if (other.main_image != null)
				return false;
		} else if (!main_image.equals(other.main_image))
			return false;
		if (main_time == null) {
			if (other.main_time != null)
				return false;
		} else if (!main_time.equals(other.main_time))
			return false;
		if (main_title == null) {
			if (other.main_title != null)
				return false;
		} else if (!main_title.equals(other.main_title))
			return false;
		return true;
	}
	
	
	
	
	
	
	
}
