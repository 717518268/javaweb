package com.wang.service.util.exception;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

/**
 * 自定义全局异常处理器
 * @author 王
 *
 */
@Service
public class AllClassException implements HandlerExceptionResolver {

	public ModelAndView resolveException(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2,
			Exception e) {
		//错误消息 
				 
				MyException myException=null;
				
				//如果为自定义异常，显示自定义消息
				if(e instanceof MyException){
					myException =(MyException)e;
				}else{
					myException=new MyException("其他bug上线啦！！");
				}
				
				
				//响应用户错误提示
				ModelAndView model = new ModelAndView();
				//返回错误消息
				model.addObject("msg", myException.getMsg());
				//响应错误提示页面
				model.setViewName("404");

	 
		
				return model;
	}

}
