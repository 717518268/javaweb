package com.wang.dao;

import java.util.List;

import com.wang.pojo.Order_table;

public interface OrderTableDao {
	/**
	 * 订单模糊查询
	 * @return
	 */
	public List<Order_table>selectByNameOrder_table(String username);
	
	/**
	 * 根据id查询
	 * @param id
	 * @return
	 */
	public Order_table selectByOrder_tableId(Integer id);
	
	/**
	 * 查所有
	 * @return
	 */
	public List<Order_table>selectAllOrder_table();
	
	/**
	 * 删除
	 * @param id
	 * @return
	 */
	public int deleteByOrder_table(Integer id);
	
	/**
	 * 批量删除订单
	 * 
	 * @return
	 */
	public int delete_ByOrder_tableAll_Ids(String []id);
	/**
	 * 添加一个订单
	 * @param order_table
	 * @return
	 */
	public int insertOrder_table(Order_table order_table);
	/**
	 * 添加一个订单
	 * @param order_table
	 * @return
	 */
	public int insertOrder_table2(Order_table order_table);
	
	/**
	 * 订单总数
	 * @return
	 */
	public int countOrder_table();
	
	/**
	 * 查个人订单的总数
	 * @return
	 */
	public int countOrder_table_ByName(String username);
	/**
	 * 修改状态
	 * set一个state
	 * @param order_table
	 * @return
	 */
	public int updateOrder_table(Order_table order_table);	
	
	//updateOrder_table_buNumber
	public int updateOrder_table_buNumber(Order_table order_table);	
}
