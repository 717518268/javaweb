package com.wang.controller.aliyun;

import java.io.IOException;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alipay.config.*;
import com.wang.pojo.Commodity_table;
import com.wang.pojo.Order_table;
import com.wang.pojo.Register_table;
import com.wang.service.Commodity_tableService;
import com.wang.service.Order_tableService;
import com.wang.service.util.RedisTempt_The_Key;
import com.alipay.api.*;
import com.alipay.api.request.*;

@Controller
public class AliyunController {
	@Autowired
	private Commodity_tableService commodity_tableService;
	@Autowired
	private Order_tableService order_tableService;
	//订单页传参数comm_name:comm_name,details:details,count:count,price:price
	public static String totalID;
	private String ZHIFUBAO;
	
	@RequestMapping("/aliyun/alipay_trade_page_pay")
	@ResponseBody
	public String toplay(HttpServletRequest request,HttpServletResponse response,HttpSession session 
			) throws IOException, AlipayApiException{
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		//获得初始化的AlipayClient
		AlipayClient alipayClient = new DefaultAlipayClient(AlipayConfig.gatewayUrl, AlipayConfig.app_id, AlipayConfig.merchant_private_key, "json", AlipayConfig.charset, AlipayConfig.alipay_public_key, AlipayConfig.sign_type);
		
		//订单号
		String order_number=request.getParameter("order_number");
		//商品名字
		String comm_name=request.getParameter("comm_name");
		//详情
		String details=request.getParameter("details");
		String price=request.getParameter("price");
	 
		//获取价格
		String address=request.getParameter("address");
		//获取地址
		//设置请求参数
		AlipayTradePagePayRequest alipayRequest = new AlipayTradePagePayRequest();
		alipayRequest.setReturnUrl(AlipayConfig.return_url);
		alipayRequest.setNotifyUrl(AlipayConfig.notify_url);
		//先查商品名称，然后再减一
		System.out.println("商品名称："+details);
		Commodity_table commodity_table=commodity_tableService.selectByOrder_tableName_Service(details);
		System.out.println("先查商品名称，然后再减一:"+commodity_table);
		int index2=commodity_tableService.updateByPrimaryKeyNameCountAuto(commodity_table);
		System.out.println("库存减少是否成功:"+index2);
		String image1=commodity_table.getImage1();
		String state="TRADE_FINISHED";
		Register_table register_table=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		//获取登录对象
		System.out.println(register_table);
		String username=register_table.getUsername();
		//商户订单号，商户网站订单系统中唯一订单号，必填
		String out_trade_no = new String( order_number.getBytes("ISO-8859-1"),"UTF-8");
		//付款金额，必填
		String total_amount = new String( price.getBytes("ISO-8859-1"),"UTF-8");
		//订单名称，必填
		String subject = new String( comm_name.getBytes("ISO-8859-1"),"UTF-8");
		//商品描述，可空
		String body = new String( details.getBytes("ISO-8859-1"),"UTF-8");
		int count=1;
		double price2=Double.parseDouble(total_amount);
		Order_table order_table=new Order_table(out_trade_no, comm_name, image1, count, price2, state, username, address);
		int i=order_tableService.insertOrder_table2_Service(order_table);
		System.out.println("添加了的订单:"+i);
		totalID=order_table.getOrder_number();
		//设置数量购买1
		//插入订单表里
		/*
		 double price2=Double.parseDouble(price);
		Order_table order_table=new Order_table(
				order_number, comm_name,
				image1, count,
				price2, state, 
				username, address);
		int index=order_tableService.insertOrder_table2_Service(order_table);
		System.out.println("插入订单表的结果："+index);
		*/
		// 该笔订单允许的最晚付款时间，逾期将关闭交易。取值范围：1m～15d。m-分钟，h-小时，d-天，1c-当天（1c-当天的情况下，无论交易何时创建，都在0点关闭）。 该参数数值不接受小数点， 如 1.5h，可转换为 90m。
	    String timeout_express = "1c";
		
		alipayRequest.setBizContent("{\"out_trade_no\":\""+ out_trade_no +"\"," 
				+ "\"total_amount\":\""+ total_amount +"\"," 
				+ "\"subject\":\""+ subject +"\"," 
				+ "\"body\":\""+ body +"\"," 
				+"\"timeout_express\":\""+timeout_express+"\","
				+ "\"product_code\":\"FAST_INSTANT_TRADE_PAY\"}");
		
		//若想给BizContent增加其他可选请求参数，以增加自定义超时时间参数timeout_express来举例说明
		//alipayRequest.setBizContent("{\"out_trade_no\":\""+ out_trade_no +"\"," 
		//		+ "\"total_amount\":\""+ total_amount +"\"," 
		//		+ "\"subject\":\""+ subject +"\"," 
		//		+ "\"body\":\""+ body +"\"," 
		//		+ "\"timeout_express\":\"10m\"," 
		//		+ "\"product_code\":\"FAST_INSTANT_TRADE_PAY\"}");
		//请求参数可查阅【电脑网站支付的API文档-alipay.trade.page.pay-请求参数】章节
		
		//请求
		String result = alipayClient.pageExecute(alipayRequest).getBody();
		
		//输出
	//	out.println(result);
		 return result;
	}
	
	
	//购物车发送过来的
	@RequestMapping("/aliyun/alipay_trade_page_payCArteView")
	@ResponseBody
	public String toplayCarteView(HttpServletRequest request,HttpServletResponse response,HttpSession session 
			) throws IOException, AlipayApiException{
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		//获得初始化的AlipayClient
		AlipayClient alipayClient = new DefaultAlipayClient(AlipayConfig.gatewayUrl, AlipayConfig.app_id, AlipayConfig.merchant_private_key, "json", AlipayConfig.charset, AlipayConfig.alipay_public_key, AlipayConfig.sign_type);
		
		
		//获取地址
		//设置请求参数
		AlipayTradePagePayRequest alipayRequest = new AlipayTradePagePayRequest();
		alipayRequest.setReturnUrl(AlipayConfig.return_url);
		alipayRequest.setNotifyUrl(AlipayConfig.notify_url);
		 
		String state="TRADE_FINISHED";
		Register_table register_table=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		//获取登录对象
		System.out.println(register_table);
		String username=register_table.getUsername();
		//商户订单号，商户网站订单系统中唯一订单号，必填
		String out_trade_no = new String( "".getBytes("ISO-8859-1"),"UTF-8");
		//付款金额，必填
		String total_amount = new String( "".getBytes("ISO-8859-1"),"UTF-8");
		//订单名称，必填
		String subject = new String( "".getBytes("ISO-8859-1"),"UTF-8");
		//商品描述，可空
		String body = new String( "".getBytes("ISO-8859-1"),"UTF-8");
		int count=1;
		double price2=Double.parseDouble(total_amount);
	
		
		 
		// 该笔订单允许的最晚付款时间，逾期将关闭交易。取值范围：1m～15d。m-分钟，h-小时，d-天，1c-当天（1c-当天的情况下，无论交易何时创建，都在0点关闭）。 该参数数值不接受小数点， 如 1.5h，可转换为 90m。
	    String timeout_express = "1c";
		
		alipayRequest.setBizContent("{\"out_trade_no\":\""+ out_trade_no +"\"," 
				+ "\"total_amount\":\""+ total_amount +"\"," 
				+ "\"subject\":\""+ subject +"\"," 
				+ "\"body\":\""+ body +"\"," 
				+"\"timeout_express\":\""+timeout_express+"\","
				+ "\"product_code\":\"FAST_INSTANT_TRADE_PAY\"}");
		
		 
		String result = alipayClient.pageExecute(alipayRequest).getBody();
		ZHIFUBAO=result;
		 return "SUCCESS";
	}
	
	//购物车发送过来的
		@RequestMapping("/aliyun/ge_payCArteView")
		
		public String ge_payCArteView(HttpServletRequest request,HttpServletResponse response,HttpSession session 
				) throws IOException, AlipayApiException{
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			 
			 
			 return ZHIFUBAO;
		}
		
	
}
