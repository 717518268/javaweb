package com.wang.service.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class testgetdateInt {
	
	 public static void main(String[] args) throws Exception {
		 String date=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()); 
		   long time=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date).getTime();
		int  changeTime=(int) (time/1000);
		System.out.println(changeTime);
	}
	
	
	 
}
