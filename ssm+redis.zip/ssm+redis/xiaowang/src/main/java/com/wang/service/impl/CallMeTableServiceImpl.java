package com.wang.service.impl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wang.dao.CallMeTableDao;
import com.wang.pojo.CallMeTable;
import com.wang.service.CallMeTableService;
/**
 * 评论关于我们的数据表
 * @author Administrator
 *
 */
@SuppressWarnings("all")
@Service
@Transactional
/**
 * 开启事务注解
 * @author Administrator
 *
 */
public class CallMeTableServiceImpl implements CallMeTableService{
	@Autowired
	private CallMeTableDao callMeTableDao;
/*	@Autowired
	private RedisTemplate redisTemplate;*/
	
	 /**
	  * 取一个列表的数据
	  * 关于我们的页面
	  */
	public List<CallMeTable> selectByCallMEAllList() {
		//先获取缓存的数据
		 
			List<CallMeTable>list=callMeTableDao.selectByCallMEAllList();
			 
		
		return list;
	}

	public CallMeTable selectByCallMETable(Integer id) {
		 
		return callMeTableDao.selectByCallMETable(id);
	}

	public Integer insertCallMETable(CallMeTable CallMeTable) {
		int index=callMeTableDao.insertCallMETable(CallMeTable);
		 
		return  index;
	}

	public Integer insertCallMETableSQL(CallMeTable CallMeTable) {
		// TODO Auto-generated method stub
		int index=callMeTableDao.insertCallMETableSQL(CallMeTable);
		 
		return index;
	}

	public Integer countByCallMETable() {
		// TODO Auto-generated method stub
		int count=callMeTableDao.countByCallMETable();
		return count;
	}

	public Integer deleteByCallMETableId(Integer id) {
		int deleteid=callMeTableDao.deleteByCallMETableId(id);
		 
		return deleteid;
	}

	public Integer updateCallMETable(CallMeTable callMeTable) {
		// TODO Auto-generated method stub
		int updateid=callMeTableDao.updateCallMETable(callMeTable);
		 
		return updateid;
	}
	
	/**
	 * 批量删除
	 */
	public int deleteByCallMETableIdIDS(String id) {
		
		String []ids=id.split(",");//进行逗号字符分割
			 
		int indexValueDelete=callMeTableDao.deleteByCallMETableIdIDS(ids);
		return  indexValueDelete;
	}

}
