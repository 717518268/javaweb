package com.wang.controller;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.CallMeTable;
import com.wang.pojo.Register_table;
import com.wang.service.CallMeTableService;
import com.wang.service.util.GetDate;
import com.wang.service.util.RedisTempt_The_Key;
/**
 * 关于我们的页面
 * 控制层
 * @author Administrator
 *
 */
@Controller
public class Connectus {
	
	@Autowired
	private CallMeTableService callMeTableService;
	
	@RequestMapping("/connectus")
	public String getview(){
		return "connectus";
	}
	
	@RequestMapping("/getusername/isnull")
	@ResponseBody
	public Object getusername(HttpSession session){
		Register_table register_table=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		if(register_table==null){
			return "notobject";
		}else{
			return register_table;
		}
	}
	
	@RequestMapping("/toinser/CallMeTable")
	@ResponseBody
	public Object toinserCallMe(HttpSession session,
			@Param("title")String title,
			@Param("email")String email,
			@Param("message")String message,
			HttpServletRequest request,
			HttpServletResponse response) throws UnsupportedEncodingException{
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		Register_table register_table=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		if(register_table==null){
			return "notobject";
		}
		System.out.println("标题："+title);
		System.out.println("内容："+message);
		String username=register_table.getUsername();
		if(title==""){
			return "notitle";
		}else if(message==""){
			return "nomessage";
		}else{
			 
			String time=GetDate.getdate();
			CallMeTable CallMeTable=new CallMeTable(username, title, email, message,time);
			int index=callMeTableService.insertCallMETable(CallMeTable);
			if(index>0){
				return  username;
			} 
			 
		}
		return "notobject";
	}
	
	
	
}
