package com.wang.controller.user;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.ibatis.annotations.Param;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.Order_table;
import com.wang.service.Order_tableService;
@SuppressWarnings("all")
@Controller
public class Order_User {
	@Autowired
	private Order_tableService order_tableService;
	@Autowired
	private RedisTemplate redisTemplate;
	 
	
	@RequestMapping("/getcountOrder_s")
	@ResponseBody
	public Object getCountOrder(){
		
	int count=order_tableService.countOrder_table_Service();
	return count;
	}
	
	
	
	/**
	 * 请求所有的订单的数据
	 * @return
	 */
	@RequestMapping("/getOrder_table_List")
	@ResponseBody
	public List<Order_table>getListOrder_table(){
		 List<Order_table>orderLsit=(List<Order_table>) redisTemplate.opsForValue().get("order_list");
		 if(orderLsit==null){
			 //设置缓存
			 orderLsit=order_tableService.selectAllOrder_table_Service();
			 redisTemplate.opsForValue().set("order_list", orderLsit, 2, TimeUnit.HOURS);
		 }
		 
		 return orderLsit;
	}
	/**
	 * 删除
	 * @param id
	 * @return
	 */
	 
	@RequestMapping("/deleteAllOneOrderTable")
	@ResponseBody
	public Object deleteAllOneOrderTable(@Param("id") Integer id){
		int index=order_tableService.deleteByOrder_table_Service(id);
		redisTemplate.delete("order_list");
		//删除key
		return index;
	}
	
	@RequestMapping("/user/deleteOrderTableIds")
	@ResponseBody
	public String deleteOrderIds(@Param("id")String id){
		
		int value=order_tableService.delete_ByOrder_tableAll_Ids(id);
		
		return "ok";		
	}
	
	 
}
