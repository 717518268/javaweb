package com.wang.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wang.pojo.Register_table;
import com.wang.service.Register_TableService;
import com.wang.service.util.GetMD5;
import com.wang.service.util.RedisTempt_The_Key;
/**
 * 登录请求控制器
 * @author Administrator
 *
 */
@Controller
public class LoginController {
	/**
	 * 依赖注入
	 */
	@Autowired
	private Register_TableService register_Service;
	@Autowired
	private RedisTemplate<String, Register_table> redisTemplate;
	private static final String SUCCESS="SUCCESS";
	private static final String ERROR="ERROR";
	/**
	 * 登录请求页面
	 * @param session
	 * @return
	 */
	@RequestMapping("/login")
	public String loginVieW(HttpSession session){
		Register_table register_table1= (Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		System.out.println("先取session的值"+register_table1);
		if(register_table1!=null){//如果sesion的值为空就更加没有redis
			Register_table register_table= redisTemplate.opsForValue().get(RedisTempt_The_Key.USERINFO(register_table1.getUsername()));
			if(register_table!=null){
				return "personalCenter";
			}
			return "redirect:login";
		}else{//有时候redis有值就设置进去
			 
			
		}
		System.out.println("暂时没有用户缓存");
		
		
		return "login";
	}
	/**
	 * 调用退出
	 * @return
	 */
	@RequestMapping("/out")
	public String out(){
		
		return "login";
	}
	
	/**
	 * 判断用户名是否存在
	 * @param username
	 * @return
	 */
	@RequestMapping(value="/Login_tousername",method=RequestMethod.POST)
	@ResponseBody
	public String TO_USername(@Param("username")String username){
		if(username!=null||username!=""){
			String nullUsername=register_Service.selectR_Username_Service2(username);
			if(nullUsername!=null){
				System.out.println("账号存在！！"+nullUsername);
				return SUCCESS;
			}
		}
		
		
		return ERROR;
	}
	
	
	/**
	 * 登录按钮请求
	 * @param username
	 * @param password
	 * @param code
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/tologinUsername",method=RequestMethod.POST)
	@ResponseBody
	public String USERname(
			@Param("username")String username,
			@Param("password")String password,
			@Param("code")String code,
			HttpSession session,HttpServletRequest request){
		System.out.println("传进来的用户名："+username);
		System.out.println("传进来的密码："+password);
	 
		//password=GetMD5.encodeToHex(password);
		//密码进行加密进行验证
		//取缓存的进行空值判断
		String codeIntSession=request.getSession().getAttribute("codeInt").toString();
		if(codeIntSession.equals(code)!=true){
			return ERROR;
		}
		Register_table register_table= redisTemplate.opsForValue().get(RedisTempt_The_Key.USERINFO(username));
		
			
				//空值判断
					register_table=new Register_table();
					password=GetMD5.encodeToHex(password);
					register_table.setUsername(username);
					register_table.setPassword(password);
			
				System.out.println("打印对象："+register_table);
				//传两个参数
				Register_table selectRegister_table =register_Service.selectREgister_Username_Password_Service(register_table);
				if(selectRegister_table!=null){//如果不等于null就进行返回响应体字符串到ajax
					//存入redis
					//读取key
					redisTemplate.opsForValue().set(RedisTempt_The_Key.USER, selectRegister_table);
					//登录按钮提交后就存进redis里
					session.setAttribute(RedisTempt_The_Key.USER, selectRegister_table);
					//一起存在会话层里
					 
				return SUCCESS;	//返回SUCCESS
				}
			
		
		return ERROR;
	}
	/**
	 * 空值判断方法
	 * @param username
	 * @param password
	 * @return
	 */
	@SuppressWarnings("unused")
	public boolean UsernameAndPassword(String username,String password){
		if(username!=null||username!=""&&password!=null||password!=""){
			return true;
		}else{
			return false; 
		}
		 
	}
	
	/**
	 * 验证码判断
	 * @param code
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/tologinCode",method=RequestMethod.POST)
	@ResponseBody
	public String TOCODE(@Param("code")String code,HttpServletRequest request){
		System.out.println("拿到前端登录的验证码:"+code);
		//获取code的session值
		String codeIntSession=request.getSession().getAttribute("codeInt").toString();
		if(code!=""||code!=null){
			if(code.equalsIgnoreCase(codeIntSession)){
				System.out.println("验证成功");
				return "SUCCESS";//登录成功返回SUCCESS
			}
		}
		
		
		return ERROR;//错误则返回
	}
	
	
	
}
