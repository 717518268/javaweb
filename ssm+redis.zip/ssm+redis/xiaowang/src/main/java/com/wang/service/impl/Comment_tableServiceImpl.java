package com.wang.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wang.dao.Comment_tableDao;
import com.wang.pojo.Comment_table;
import com.wang.service.Comment_tableService;
/**
 * 业务层
 * @author Administrator
 *
 */
@Service
@Transactional
public class Comment_tableServiceImpl implements Comment_tableService{
	@Autowired
	private Comment_tableDao comment_tableDao;
	
	/**
	 * set商品名字
	 */
	public List<Comment_table> selectByComment_table_Service(Comment_table comment_table) {
		// TODO Auto-generated method stub
		return comment_tableDao.selectByComment_table(comment_table);
	}
	/**
	 * 根据id查询单个
	 */
	public Comment_table selectByComment_tableID_Service(Integer cid) {
		// TODO Auto-generated method stub
		return comment_tableDao.selectByComment_tableID(cid);
	}
	/**
	 * 根据cid删除
	 */
	public int deleteByComment_table_Service(Integer cid) {
		// TODO Auto-generated method stub
		return comment_tableDao.deleteByComment_table(cid);
	}

	/**
	 * 默认把点赞数量传进来，
	 * 设置初始值为零
	 */
	public int insertComment_table_Service(Comment_table comment_table) {
		// TODO Auto-generated method stub
		return comment_tableDao.insertComment_table(comment_table);
	}

	public int insertSQLComment_table_Service(Comment_table comment_table) {
		// TODO Auto-generated method stub
		return comment_tableDao.insertSQLComment_table(comment_table);
	}

	public Integer Comment_tablecount_Service(String name) {
		// TODO Auto-generated method stub
		return comment_tableDao.Comment_tablecount(name);
	}
	/**
	 * 点赞增加累加
	 */
	public Integer updatePraiseComment_table_Service(Comment_table comment_table) {
		// TODO Auto-generated method stub
		return comment_tableDao.updatePraiseComment_table(comment_table);
	}
	public List<Comment_table> selectBymyselListComment_table(Comment_table comment_table) {
		// TODO Auto-generated method stub
		return comment_tableDao.selectBymyselListComment_table(comment_table);
	}
	
	/**
	 * 批量删除
	 */
	public int deleteComment_tableIds(String cid) {
		String[] cids=cid.split(",");
		int value=comment_tableDao.deleteComment_tableIds(cids);
		return  value;
	}

}
