package com.wang.service.util.exception;

import java.io.Serializable;

/**
 * Apt统一的返回结果类
 */
public class MyException extends Exception implements Serializable{
	 
    /**
	 * 
	 */
	private static final long serialVersionUID = -8837478360320565984L;
	/**
     * 结果码描述
     */
    private String msg;

	public MyException(String msg) {
		super();
		this.msg = msg;
	}

	public MyException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "ApiResult [msg=" + msg + "]";
	}

	 
    
    
}
