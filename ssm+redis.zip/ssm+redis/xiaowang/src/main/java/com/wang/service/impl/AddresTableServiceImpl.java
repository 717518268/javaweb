package com.wang.service.impl;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wang.dao.Address_tableDao;
import com.wang.pojo.Address_table;
import com.wang.service.Address_tableService;

@Service
@Transactional
public class AddresTableServiceImpl implements Address_tableService{
	
	@Autowired
	private Address_tableDao address_tableDao;
	
	/**
	 * 	鏍规嵁鐢ㄦ埛鍚嶆煡鎬绘暟
	 * @param address_name
	 * @return
	 */
	public int countByExample_Service(String address_name) {
		// TODO Auto-generated method stub
		return address_tableDao.countByExample(address_name);
	}
	/**
	 * 鏍规嵁id鍜屽悕瀛楀垹闄や竴涓湴锟�?
	 * @param address_id
	 * @return
	 */
	public int deleteByPrimaryKey_Service(Integer address_id) {
		// TODO Auto-generated method stub
		return address_tableDao.deleteByPrimaryKey(address_id);
	}
	/**
	 * 	鏌ヨ鍏ㄩ儴
	 * @return
	 */
	public List<Address_table> selectByAddress_table_ALL_Service() {
		// TODO Auto-generated method stub
		return address_tableDao.selectByAddress_table_ALL();
	}
	/**
	 * 妯＄硦鏌ヨ
	 * @param address_name
	 * @return
	 */
	public List<Address_table> selectByPrimaryKey_Service(String address_name) {
		// TODO Auto-generated method stub
		return address_tableDao.selectByPrimaryKey(address_name);
	}
	/**
	 * 	娣诲姞锟�?涓湴锟�?
	 * @param address_table
	 * @return
	 */
	public int insertAdresss_table_Service(Address_table address_table) {
		// TODO Auto-generated method stub
		return address_tableDao.insertAdresss_table(address_table);
	}
	/**
	 * 	娣诲姞锟�?涓湴锟�?
	 *	 鍔拷?锟絊QL
	 * @param address_table
	 * @return
	 */
	public int insertSelectiveAddress_Service(Address_table address_table) {
		// TODO Auto-generated method stub
		return address_tableDao.insertSelectiveAddress(address_table);
	}
	/**
	 * 	淇敼
	 * @param address_table
	 * @return
	 */
	public int updateByPrimars3_Service(Address_table address_table) {
		// TODO Auto-generated method stub
		return address_tableDao.updateByPrimars3(address_table);
	}
	/**
	 * 淇敼2
	 * @param address_table
	 * @return
	 */
	public int updateByPrimaryKeySelective_Service(Address_table address_table) {
		// TODO Auto-generated method stub
		return address_tableDao.updateByPrimaryKeySelective(address_table);
	}
	public Address_table selectByAddress_table_Id_Service(Integer id) {
		// TODO Auto-generated method stub
		return address_tableDao.selectByAddress_table_Id(id);
	}
	
	/**
	 * 根据username查询地址
	 */
	public Address_table selectByAddress_table_UserNAme(String username) {
		 
		return address_tableDao.selectByAddress_table_UserNAme(username);
	}
	public int CountComment() {
		// TODO Auto-generated method stub
		return address_tableDao.CountComment();
	}
	public int DeleteAll_IDS_Chexbox(String[] id) {
		// TODO Auto-generated method stub
		return address_tableDao.DeleteAll_IDS_Chexbox(id);
	}

}
