package com.wang.service;

import java.util.List;

import com.wang.pojo.Weixin_table;

public interface Weixin_tableService {
	
	public int  insertOpendids_Service(Weixin_table weixin_table);
	
	public Weixin_table selectGetNameOpenidCount_Service(String openid);
	
	public List<Weixin_table>selectALLOpenid_Service();
	
	
	
}
