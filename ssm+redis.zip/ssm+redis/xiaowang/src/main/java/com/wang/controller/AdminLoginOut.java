package com.wang.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wang.service.util.RedisTempt_The_Key;
/**
 * 退出登录清空session
 * @author Administrator
 *
 */
@Controller
public class AdminLoginOut {
	
	/**
	 * 退出session
	 * 退出登录
	 * @param session
	 * @return
	 */
	@RequestMapping("/loginout")
	public String adminout(HttpSession session){
	
	//	Register_table register_table1=(Register_table) session.getAttribute(RedisTempt_The_Key.USER);
		session.removeAttribute(RedisTempt_The_Key.USER);
		session.invalidate();
		/**
		 *  
		 *  
		 */
		return "out";
		
	}
	
}
