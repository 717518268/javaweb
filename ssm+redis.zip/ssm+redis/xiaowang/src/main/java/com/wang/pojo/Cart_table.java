package com.wang.pojo;

import java.io.Serializable;

public class Cart_table implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6311374897745500549L;
	
	private Integer id;
	private String username;
	private String comm_name;
	private String imagecart;
	private int count;
	private double price;
	private String details;
	public Cart_table() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cart_table(String username, String comm_name, String imagecart, int count, double price, String details) {
		super();
		this.username = username;
		this.comm_name = comm_name;
		this.imagecart = imagecart;
		this.count = count;
		this.price = price;
		this.details = details;
	}
	@Override
	public String toString() {
		return "Cart_table [id=" + id + ", username=" + username + ", comm_name=" + comm_name + ", imagecart="
				+ imagecart + ", count=" + count + ", price=" + price + ", details=" + details + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((comm_name == null) ? 0 : comm_name.hashCode());
		result = prime * result + count;
		result = prime * result + ((details == null) ? 0 : details.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((imagecart == null) ? 0 : imagecart.hashCode());
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cart_table other = (Cart_table) obj;
		if (comm_name == null) {
			if (other.comm_name != null)
				return false;
		} else if (!comm_name.equals(other.comm_name))
			return false;
		if (count != other.count)
			return false;
		if (details == null) {
			if (other.details != null)
				return false;
		} else if (!details.equals(other.details))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (imagecart == null) {
			if (other.imagecart != null)
				return false;
		} else if (!imagecart.equals(other.imagecart))
			return false;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getComm_name() {
		return comm_name;
	}
	public void setComm_name(String comm_name) {
		this.comm_name = comm_name;
	}
	public String getImagecart() {
		return imagecart;
	}
	public void setImagecart(String imagecart) {
		this.imagecart = imagecart;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
