﻿package com.alipay.config;

import java.io.FileWriter;

import java.io.IOException;

/* *
 *类名：AlipayConfig
 *功能：基础配置类
 *详细：设置帐户有关信息及返回路径
 *修改日期：2017-04-05
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */

public class AlipayConfig {
	
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

	// 应用ID,您的APPID，收款账号既是您的APPID对应支付宝账号
	public static String app_id ="2016100100639666";
	
	// 商户私钥，您的PKCS8格式RSA2私钥
    public static String merchant_private_key ="MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDkpg+n0lcHuzhJ/SwNJAVtIa5YNWoSbsgjvaoLJEWAslueHqe99Xo/34RnSJgOQ6GAYSPCo/VDtHCMPq+VMpmTu4RpkQ733SwtJMLOGczaJhutmjCE1ZD65dAZ0B8+MK4oP6nXNikljWG4Tar2O5m658+xQJOpYYNSNAKoXne2qHNsgKYHnQQn6jDveW95PBRZ4NyQeqZwoci+q/YYWUmSipCf2vTwpuGpEFIwsJlN41KgQF8h/BU2DZAO8EcByB0QTADGmCjzNU0WoDGxyDfvhyuk/t4WX7etUz8GTyLzXQKmfyyxGEuRB51SSq4BStMHwFadM6dKX1v2Vq4iUBt3AgMBAAECggEBAN6VxlHSUwTkvhRREOwt79ZgXm/id8M/8zfP8FRuV/bEKqpQH22uJfc+KY++PMBOGE94wS4/HIlvg80TTSyKGLWXa3y1SQQEXHgJ/FZVCXYoePNUUf1ORpfo1t/6GiAZlcD60OUABahX7RRVD6QrOymXdzmPqu/OTN/eX+P2KsY1eSFo9PQhTdp75sd9rVLsIp2XDWk6XAmHZ9sOP0j1j4pfh8nUMrIqV0JV4wq4uxsFs9WEYjpFpAz2qA3huILu7Qvn+rdQV33+pCJySnvbX+tdLJz/ALCZ0Y+bwBqOfdKhqrdDN+udrj2oEX303zeTnJuQlg860KvsDCdQdKGgeJECgYEA9hJDIwOOwXajhGzqmKdlhFB7pPQawKCc7nWDPkBKrysZWAU5EKKOTVHsHVRD3jfyj1JlieKAVde4eb36yjuUlWfUQNa9iefQK8DU+tpz7TADQqzxxdKTE9eBsV63NuhbVg3FUFYDYnNI1e7rg0dVWOs6ROKzPARHf1J0wk/75AkCgYEA7d/V443/+cjLf3qfi1ouNS85OBM+rimIyRX+c7igf9U4ADGEsKQvraUpcQDkZTNyJ2K0E4hw6H/OgikpsJUSwES/GW7N8TWPFeD5JIsGtIiL19GC+3bHBpRjSL/APTixKwB54xoE2Ubv9vk4jY0M8B0CKhwd4MF9aJL+ulV2438CgYEAjyTYgUnUhZ5qSOLDJcJbP7lB9Bc8aMoGAIHDszbbO0MrHxUKuS6W8Uuyuu0F/gM1y0H3Z1qnpUg0PD3T4kj+ils4Ee/ZmpuLcahfPP5Paa8Adoz8qENy45v+Chw7IGnSmCCyo6UlmuPNfwXZYyjf8TYFU4U9FrC2ls50tYSp12ECgYEAr335sJ3sgX2QFIaE+iwX9wjV7/bSwW7HCYN+bCWD04ucexgNSrx2qGc3QbVkyvy/dSsuq1J36i+QTRrNNQdmBA8z5TGIIjJfU8bcSAeBdONgOGLLfXXNs575+Ivu6bvPiWgahF+HwDzDgLOw801ihCsCk8qWiGB3gxUfdJzkz0UCgYAe2uhyc8Gty6IgZKPZR25HS6Td9GRqCDC/bnjuGQwiBrg0SjUf36wpm0EmjNf96zd5nqn+iM0JdJ4iapQxyd0PUoxBmebspp6xgYmLXyCvqpuTyue7x6pccu+wViFU0CHShpYL0iJXyr63tZObP9FkhcqfVkr/3lGO7w8/OAKbLA==";
    
    // 支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
    public static String alipay_public_key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqpnwU1kMWqViz0dKPTypdVqn/NkQA8F5cTGdisbv/zXuwe0jRWuzRtRl66GQW/37NN/bKHHhxiYB0w95yqxTI11rtrlMsxsiGqb90LAExE54LV8wvPFPjUGMwvZmM/DTeiU0es73oBZjIeNlTdj8OnbHvu3f2VvQJG+WBxuDwj4WLH1/nYQQ7tWSzxu3Z/cxxxfCJSUg3URdOytAMou3Fo3bZY/vjJinZNJQnu6TXKd9vK2rWwjFBqS7uhqKogUF3Uq06jWFFXi6C5TUgmF9vHyhKgvXd6/KJyCDdeyECMFSiapF4Mr9FFsdhnTDNvg8h3OL6cTWqeD6t4/haW0I+QIDAQAB";

	// 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String notify_url = "http://localhost:8080/xiaowang/aliyun/notify_url";

	// 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String return_url = "http://localhost:8080/xiaowang/aliyun/return_url";

	// 签名方式
	public static String sign_type = "RSA2";
	
	// 字符编码格式
	public static String charset = "utf-8";
	
	// 支付宝网关
	public static String gatewayUrl = "https://openapi.alipaydev.com/gateway.do";
	
	// 支付宝网关
	public static String log_path = "C:\\test";


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

    /** 
     * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
     * @param sWord 要写入日志里的文本内容
     */
    public static void logResult(String sWord) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(log_path + "alipay_log_" + System.currentTimeMillis()+".txt");
            writer.write(sWord);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

