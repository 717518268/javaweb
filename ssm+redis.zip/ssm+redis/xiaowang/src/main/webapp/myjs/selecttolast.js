	function change(ev){       
						  var event = window.event || ev;
						  var files = event.target.files[0];
						  var myimg = document.getElementById("myimg1");
						  myimg.src = URL.createObjectURL(files);
		}
			function change2(ev){       
						  var event = window.event || ev;
						  var files = event.target.files[0];
						  var myimg = document.getElementById("myimg2");
						  myimg.src = URL.createObjectURL(files);
		}
			function change3(ev){       
						  var event = window.event || ev;
						  var files = event.target.files[0];
						  var myimg = document.getElementById("myimg3");
						  myimg.src = URL.createObjectURL(files);
		}
			function change4(ev){       
						  var event = window.event || ev;
						  var files = event.target.files[0];
						  var myimg = document.getElementById("myimg4");
						  myimg.src = URL.createObjectURL(files);
		}
			function change5(ev){       
				  var event = window.event || ev;
				  var files = event.target.files[0];
				  var myimg = document.getElementById("myimg5");
				  myimg.src = URL.createObjectURL(files);
}